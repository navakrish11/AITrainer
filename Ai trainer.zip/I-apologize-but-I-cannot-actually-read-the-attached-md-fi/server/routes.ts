import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import multer from "multer";
import { z } from "zod";
import { insertUserSchema, insertCourseSchema, insertModuleSchema, insertQuizSchema, insertEnrollmentSchema, insertProgressSchema, insertQuizAttemptSchema } from "@shared/schema";
import fs from "fs";
import path from "path";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";
const AZURE_OPENAI_ENDPOINT = process.env.AZURE_OPENAI_ENDPOINT || process.env.OPENAI_API_ENDPOINT || "";
const AZURE_OPENAI_KEY = process.env.AZURE_OPENAI_KEY || process.env.OPENAI_API_KEY || "";
const HEYGEN_API_KEY = process.env.HEYGEN_API_KEY || "";

// Middleware for authentication
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'No token provided' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      console.log('JWT verification error:', err);
      return res.status(401).json({ message: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// Middleware for trainer-only routes
const requireTrainer = (req: any, res: any, next: any) => {
  if (req.user?.role !== 'trainer') {
    return res.status(403).json({ message: 'Trainer access required' });
  }
  next();
};

// File upload configuration
const upload = multer({
  dest: 'uploads/',
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Only PDF files are allowed'));
    }
  }
});

// Azure OpenAI API integration
async function generateSummaryWithAI(text: string, customPrompt?: string): Promise<string> {
  if (!AZURE_OPENAI_ENDPOINT || !AZURE_OPENAI_KEY) {
    throw new Error('Azure OpenAI credentials not configured');
  }

  const prompt = customPrompt || "Please provide a concise summary of the following content, focusing on key concepts and main points:";
  
  try {
    const response = await fetch(`${AZURE_OPENAI_ENDPOINT}/openai/deployments/gpt-35-turbo/chat/completions?api-version=2023-12-01-preview`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'api-key': AZURE_OPENAI_KEY,
      },
      body: JSON.stringify({
        messages: [
          { role: 'system', content: 'You are a helpful assistant that creates educational summaries.' },
          { role: 'user', content: `${prompt}\n\nContent: ${text}` }
        ],
        max_tokens: 500,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      throw new Error(`Azure OpenAI API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.choices[0]?.message?.content || 'Summary could not be generated.';
  } catch (error) {
    console.error('Azure OpenAI API error:', error);
    throw new Error('Failed to generate AI summary');
  }
}

// HeyGen API integration
async function generateVideoWithHeyGen(text: string, avatarId: string, voiceId: string): Promise<string> {
  if (!HEYGEN_API_KEY) {
    throw new Error('HeyGen API key not configured');
  }

  try {
    const response = await fetch('https://api.heygen.com/v2/video/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-KEY': HEYGEN_API_KEY,
      },
      body: JSON.stringify({
        video_inputs: [{
          character: {
            type: 'avatar',
            avatar_id: avatarId,
            avatar_style: 'normal'
          },
          voice: {
            type: 'text',
            input_text: text,
            voice_id: voiceId
          }
        }],
        dimension: {
          width: 1280,
          height: 720
        }
      }),
    });

    if (!response.ok) {
      throw new Error(`HeyGen API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.data?.video_id || '';
  } catch (error) {
    console.error('HeyGen API error:', error);
    throw new Error('Failed to generate video with HeyGen');
  }
}

// PDF text extraction (placeholder - would use actual PDF processing library)
function extractTextFromPDF(filePath: string): Promise<{ pageCount: number; pages: string[] }> {
  return new Promise((resolve) => {
    // In a real implementation, use a library like pdf-parse or pdf2pic
    // For now, return mock data based on file existence
    const pageCount = Math.floor(Math.random() * 20) + 5; // 5-25 pages
    const pages = Array.from({ length: pageCount }, (_, i) => 
      `This is the extracted text content from page ${i + 1} of the uploaded PDF. This would contain the actual text content that would be processed by AI for summarization.`
    );
    
    setTimeout(() => resolve({ pageCount, pages }), 1000);
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.extend({
        email: z.string().email(),
        confirmPassword: z.string()
      }).parse(req.body);

      if (userData.password !== userData.confirmPassword) {
        return res.status(400).json({ message: "Passwords don't match" });
      }

      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);

      const user = await storage.createUser({
        ...userData,
        password: hashedPassword
      });

      const token = jwt.sign({ userId: user.id, role: user.role }, JWT_SECRET);
      res.json({ token, user: { ...user, password: undefined } });
    } catch (error) {
      res.status(400).json({ message: "Invalid input data" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;

      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = jwt.sign({ userId: user.id, role: user.role }, JWT_SECRET);
      res.json({ token, user: { ...user, password: undefined } });
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json({ ...user, password: undefined });
    } catch (error) {
      res.status(500).json({ message: "Failed to get user data" });
    }
  });

  // Course routes
  app.get("/api/courses", async (req, res) => {
    try {
      const { domain, search, trainerId } = req.query;
      
      let courses;
      if (trainerId && typeof trainerId === 'string') {
        courses = await storage.getCoursesByTrainer(parseInt(trainerId));
      } else if (domain && typeof domain === 'string') {
        courses = await storage.getCoursesByDomain(domain);
      } else if (search && typeof search === 'string') {
        courses = await storage.searchCourses(search);
      } else {
        courses = await storage.getPublishedCourses();
      }
      
      res.json(courses);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });

  app.get("/api/courses/:id", async (req, res) => {
    try {
      const courseId = parseInt(req.params.id);
      const course = await storage.getCourse(courseId);
      
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      res.json(course);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch course" });
    }
  });

  app.post("/api/courses", authenticateToken, requireTrainer, async (req: any, res) => {
    try {
      const courseData = insertCourseSchema.parse({
        ...req.body,
        trainerId: req.user.userId
      });

      const course = await storage.createCourse(courseData);
      res.json(course);
    } catch (error) {
      res.status(400).json({ message: "Invalid course data" });
    }
  });

  app.put("/api/courses/:id", authenticateToken, requireTrainer, async (req: any, res) => {
    try {
      const courseId = parseInt(req.params.id);
      const updates = req.body;

      const course = await storage.updateCourse(courseId, updates);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }

      res.json(course);
    } catch (error) {
      res.status(400).json({ message: "Failed to update course" });
    }
  });

  // Module routes
  app.get("/api/courses/:courseId/modules", async (req, res) => {
    try {
      const courseId = parseInt(req.params.courseId);
      const modules = await storage.getModulesByCourse(courseId);
      res.json(modules);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch modules" });
    }
  });

  app.post("/api/courses/:courseId/modules", authenticateToken, requireTrainer, async (req: any, res) => {
    try {
      const courseId = parseInt(req.params.courseId);
      const moduleData = insertModuleSchema.parse({
        ...req.body,
        courseId
      });

      const module = await storage.createModule(moduleData);
      res.json(module);
    } catch (error) {
      res.status(400).json({ message: "Invalid module data" });
    }
  });

  // Quiz routes
  app.get("/api/courses/:courseId/quizzes", async (req, res) => {
    try {
      const courseId = parseInt(req.params.courseId);
      const quizzes = await storage.getQuizzesByCourse(courseId);
      res.json(quizzes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quizzes" });
    }
  });

  app.get("/api/modules/:moduleId/quizzes", async (req, res) => {
    try {
      const moduleId = parseInt(req.params.moduleId);
      const quizzes = await storage.getQuizzesByModule(moduleId);
      res.json(quizzes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quizzes" });
    }
  });

  app.post("/api/quizzes", authenticateToken, requireTrainer, async (req: any, res) => {
    try {
      const quizData = insertQuizSchema.parse(req.body);
      const quiz = await storage.createQuiz(quizData);
      res.json(quiz);
    } catch (error) {
      res.status(400).json({ message: "Invalid quiz data" });
    }
  });

  // Enrollment routes
  app.get("/api/enrollments", authenticateToken, async (req: any, res) => {
    try {
      const enrollments = await storage.getEnrollmentsByUser(req.user.userId);
      res.json(enrollments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch enrollments" });
    }
  });

  app.post("/api/enrollments", authenticateToken, async (req: any, res) => {
    try {
      const enrollmentData = insertEnrollmentSchema.parse({
        ...req.body,
        userId: req.user.userId
      });

      // Check if already enrolled
      const existingEnrollment = await storage.getEnrollment(req.user.userId, enrollmentData.courseId);
      if (existingEnrollment) {
        return res.status(400).json({ message: "Already enrolled in this course" });
      }

      const enrollment = await storage.createEnrollment(enrollmentData);
      res.json(enrollment);
    } catch (error) {
      res.status(400).json({ message: "Failed to enroll in course" });
    }
  });

  // Progress routes
  app.get("/api/progress", authenticateToken, async (req: any, res) => {
    try {
      const { courseId } = req.query;
      
      let progress;
      if (courseId) {
        progress = await storage.getProgressByCourse(req.user.userId, parseInt(courseId as string));
      } else {
        progress = await storage.getProgressByUser(req.user.userId);
      }
      
      res.json(progress);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch progress" });
    }
  });

  app.post("/api/progress", authenticateToken, async (req: any, res) => {
    try {
      const progressData = insertProgressSchema.parse({
        ...req.body,
        userId: req.user.userId
      });

      // Check if progress already exists
      const existingProgress = await storage.getProgress(req.user.userId, progressData.moduleId!);
      if (existingProgress) {
        const updatedProgress = await storage.updateProgress(existingProgress.id, progressData);
        return res.json(updatedProgress);
      }

      const progress = await storage.createProgress(progressData);
      res.json(progress);
    } catch (error) {
      res.status(400).json({ message: "Failed to update progress" });
    }
  });

  // Quiz attempt routes
  app.post("/api/quiz-attempts", authenticateToken, async (req: any, res) => {
    try {
      const attemptData = insertQuizAttemptSchema.parse({
        ...req.body,
        userId: req.user.userId
      });

      const attempt = await storage.createQuizAttempt(attemptData);
      res.json(attempt);
    } catch (error) {
      res.status(400).json({ message: "Failed to submit quiz attempt" });
    }
  });

  // Certificate routes
  app.get("/api/certificates", authenticateToken, async (req: any, res) => {
    try {
      const certificates = await storage.getCertificatesByUser(req.user.userId);
      res.json(certificates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch certificates" });
    }
  });

  // File upload routes (Trainer only)
  app.post("/api/courses/:courseId/upload", authenticateToken, requireTrainer, upload.single('pdf'), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No PDF file uploaded" });
      }

      const courseId = parseInt(req.params.courseId);
      
      // Extract text from PDF
      const { pageCount, pages } = await extractTextFromPDF(req.file.path);
      
      // Store the file metadata in database
      const material = await storage.createCourseMaterial({
        courseId,
        pdfUrl: req.file.path,
        pageCount
      });

      // Create page summaries for each page (initially empty)
      for (let i = 0; i < pageCount; i++) {
        await storage.createPageSummary({
          materialId: material.id,
          pageNumber: i + 1,
          originalText: pages[i],
          summary: null,
          status: "pending"
        });
      }

      res.json({ 
        message: "PDF uploaded successfully",
        material,
        status: "ready_for_summarization",
        pageCount
      });
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ message: "Failed to upload PDF" });
    }
  });

  // Course material routes
  app.get("/api/courses/:courseId/material", authenticateToken, requireTrainer, async (req: any, res) => {
    try {
      const courseId = parseInt(req.params.courseId);
      const material = await storage.getCourseMaterial(courseId);
      
      if (!material) {
        return res.status(404).json({ message: "No material found for this course" });
      }
      
      res.json(material);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch course material" });
    }
  });

  // AI Summarization routes (Trainer only)
  app.post("/api/materials/:materialId/summarize", authenticateToken, requireTrainer, async (req: any, res) => {
    try {
      const materialId = parseInt(req.params.materialId);
      
      // Get all page summaries for this material
      const pageSummaries = await storage.getPageSummariesByMaterial(materialId);
      
      if (pageSummaries.length === 0) {
        return res.status(404).json({ message: "No pages found for this material" });
      }

      // Generate summaries for each page using Azure OpenAI
      const updatedSummaries = [];
      for (const pageSummary of pageSummaries) {
        if (pageSummary.originalText) {
          try {
            const aiSummary = await generateSummaryWithAI(pageSummary.originalText);
            const updated = await storage.updatePageSummary(pageSummary.id, {
              summary: aiSummary,
              status: "pending"
            });
            if (updated) updatedSummaries.push(updated);
          } catch (error) {
            console.error(`Failed to generate summary for page ${pageSummary.pageNumber}:`, error);
            // Continue with other pages
          }
        }
      }

      res.json({ 
        message: "Summaries generated successfully",
        summaries: updatedSummaries
      });
    } catch (error) {
      console.error('Summarization error:', error);
      res.status(500).json({ message: "Failed to generate summaries" });
    }
  });

  app.get("/api/materials/:materialId/summaries", authenticateToken, requireTrainer, async (req: any, res) => {
    try {
      const materialId = parseInt(req.params.materialId);
      const summaries = await storage.getPageSummariesByMaterial(materialId);
      res.json(summaries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch summaries" });
    }
  });

  app.put("/api/summaries/:summaryId", authenticateToken, requireTrainer, async (req: any, res) => {
    try {
      const summaryId = parseInt(req.params.summaryId);
      const updates = req.body;

      const summary = await storage.updatePageSummary(summaryId, updates);
      if (!summary) {
        return res.status(404).json({ message: "Summary not found" });
      }

      res.json(summary);
    } catch (error) {
      res.status(400).json({ message: "Failed to update summary" });
    }
  });

  // Regenerate summary with custom prompt
  app.post("/api/summaries/:summaryId/regenerate", authenticateToken, requireTrainer, async (req: any, res) => {
    try {
      const summaryId = parseInt(req.params.summaryId);
      const { customPrompt } = req.body;

      const summary = await storage.getPageSummary(summaryId);
      if (!summary || !summary.originalText) {
        return res.status(404).json({ message: "Summary not found or no original text available" });
      }

      const aiSummary = await generateSummaryWithAI(summary.originalText, customPrompt);
      const updated = await storage.updatePageSummary(summaryId, {
        summary: aiSummary,
        status: "pending"
      });

      res.json(updated);
    } catch (error) {
      console.error('Regeneration error:', error);
      res.status(500).json({ message: "Failed to regenerate summary" });
    }
  });

  // Avatar video generation routes (Trainer only)
  app.post("/api/summaries/:summaryId/generate-video", authenticateToken, requireTrainer, async (req: any, res) => {
    try {
      const summaryId = parseInt(req.params.summaryId);
      const { avatarId, voiceId } = req.body;

      if (!avatarId || !voiceId) {
        return res.status(400).json({ message: "Avatar ID and Voice ID are required" });
      }

      const summary = await storage.getPageSummary(summaryId);
      if (!summary || !summary.summary) {
        return res.status(404).json({ message: "Summary not found or not approved" });
      }

      // Create avatar video record
      const video = await storage.createAvatarVideo({
        summaryId,
        avatarId,
        voiceId,
        status: "generating"
      });

      // Generate video with HeyGen API
      try {
        const heygenJobId = await generateVideoWithHeyGen(summary.summary, avatarId, voiceId);
        
        await storage.updateAvatarVideo(video.id, {
          heygenJobId,
          status: "generating"
        });

        // In a real implementation, you would poll the HeyGen API for completion
        // For now, simulate completion after a delay
        setTimeout(async () => {
          try {
            await storage.updateAvatarVideo(video.id, {
              status: "completed",
              videoUrl: `https://api.heygen.com/v1/video_status/${heygenJobId}/download`
            });
          } catch (error) {
            console.error('Error updating video status:', error);
          }
        }, 30000); // 30 seconds

        res.json({
          message: "Video generation started",
          video: await storage.getAvatarVideo(video.id)
        });
      } catch (error) {
        await storage.updateAvatarVideo(video.id, {
          status: "failed"
        });
        throw error;
      }
    } catch (error) {
      console.error('Video generation error:', error);
      res.status(500).json({ message: "Failed to generate video" });
    }
  });

  app.get("/api/summaries/:summaryId/videos", authenticateToken, requireTrainer, async (req: any, res) => {
    try {
      const summaryId = parseInt(req.params.summaryId);
      const videos = await storage.getAvatarVideosBySummary(summaryId);
      res.json(videos);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch videos" });
    }
  });

  // HeyGen API helpers
  app.get("/api/heygen/avatars", authenticateToken, requireTrainer, async (req: any, res) => {
    try {
      if (!HEYGEN_API_KEY) {
        return res.status(500).json({ message: "HeyGen API key not configured" });
      }

      const response = await fetch('https://api.heygen.com/v2/avatars', {
        headers: {
          'X-API-KEY': HEYGEN_API_KEY,
        },
      });

      if (!response.ok) {
        throw new Error(`HeyGen API error: ${response.statusText}`);
      }

      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error('HeyGen avatars error:', error);
      res.status(500).json({ message: "Failed to fetch avatars" });
    }
  });

  app.get("/api/heygen/voices", authenticateToken, requireTrainer, async (req: any, res) => {
    try {
      if (!HEYGEN_API_KEY) {
        return res.status(500).json({ message: "HeyGen API key not configured" });
      }

      const response = await fetch('https://api.heygen.com/v2/voices', {
        headers: {
          'X-API-KEY': HEYGEN_API_KEY,
        },
      });

      if (!response.ok) {
        throw new Error(`HeyGen API error: ${response.statusText}`);
      }

      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error('HeyGen voices error:', error);
      res.status(500).json({ message: "Failed to fetch voices" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
