import { 
  users, courses, modules, quizzes, enrollments, progress, quizAttempts, 
  certificates, courseMaterials, pageSummaries, avatarVideos,
  type User, type InsertUser, type Course, type InsertCourse,
  type Module, type InsertModule, type Quiz, type InsertQuiz,
  type Enrollment, type InsertEnrollment, type Progress, type InsertProgress,
  type QuizAttempt, type InsertQuizAttempt, type Certificate, type InsertCertificate,
  type CourseMaterial, type InsertCourseMaterial, type PageSummary, type InsertPageSummary,
  type AvatarVideo, type InsertAvatarVideo
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, like } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;

  // Course methods
  getCourse(id: number): Promise<Course | undefined>;
  getCoursesByTrainer(trainerId: number): Promise<Course[]>;
  getCoursesByDomain(domain: string): Promise<Course[]>;
  getPublishedCourses(): Promise<Course[]>;
  searchCourses(query: string): Promise<Course[]>;
  createCourse(insertCourse: InsertCourse): Promise<Course>;
  updateCourse(id: number, updates: Partial<Course>): Promise<Course>;

  // Module methods
  getModulesByCourse(courseId: number): Promise<Module[]>;
  createModule(insertModule: InsertModule): Promise<Module>;

  // Quiz methods
  getQuizzesByCourse(courseId: number): Promise<Quiz[]>;
  getQuizzesByModule(moduleId: number): Promise<Quiz[]>;
  createQuiz(insertQuiz: InsertQuiz): Promise<Quiz>;

  // Enrollment methods
  getEnrollment(userId: number, courseId: number): Promise<Enrollment | undefined>;
  getEnrollmentsByUser(userId: number): Promise<Enrollment[]>;
  createEnrollment(insertEnrollment: InsertEnrollment): Promise<Enrollment>;

  // Progress methods
  getProgress(userId: number, moduleId: number): Promise<Progress | undefined>;
  getProgressByCourse(userId: number, courseId: number): Promise<Progress[]>;
  getProgressByUser(userId: number): Promise<Progress[]>;
  createProgress(insertProgress: InsertProgress): Promise<Progress>;
  updateProgress(id: number, updates: Partial<Progress>): Promise<Progress>;

  // Quiz attempt methods
  createQuizAttempt(insertQuizAttempt: InsertQuizAttempt): Promise<QuizAttempt>;

  // Certificate methods
  getCertificatesByUser(userId: number): Promise<Certificate[]>;

  // Course material methods
  getCourseMaterial(id: number): Promise<CourseMaterial | undefined>;
  createCourseMaterial(insertCourseMaterial: InsertCourseMaterial): Promise<CourseMaterial>;

  // Page summary methods
  getPageSummary(id: number): Promise<PageSummary | undefined>;
  getPageSummariesByMaterial(materialId: number): Promise<PageSummary[]>;
  createPageSummary(insertPageSummary: InsertPageSummary): Promise<PageSummary>;
  updatePageSummary(id: number, updates: Partial<PageSummary>): Promise<PageSummary>;

  // Avatar video methods
  getAvatarVideo(id: number): Promise<AvatarVideo | undefined>;
  getAvatarVideosBySummary(summaryId: number): Promise<AvatarVideo[]>;
  createAvatarVideo(insertAvatarVideo: InsertAvatarVideo): Promise<AvatarVideo>;
  updateAvatarVideo(id: number, updates: Partial<AvatarVideo>): Promise<AvatarVideo>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Course methods
  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course || undefined;
  }

  async getCoursesByTrainer(trainerId: number): Promise<Course[]> {
    return await db.select().from(courses).where(eq(courses.trainerId, trainerId));
  }

  async getCoursesByDomain(domain: string): Promise<Course[]> {
    return await db.select().from(courses).where(eq(courses.domain, domain));
  }

  async getPublishedCourses(): Promise<Course[]> {
    return await db.select().from(courses).where(eq(courses.status, 'published'));
  }

  async searchCourses(query: string): Promise<Course[]> {
    return await db.select().from(courses).where(like(courses.title, `%${query}%`));
  }

  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const [course] = await db.insert(courses).values(insertCourse).returning();
    return course;
  }

  async updateCourse(id: number, updates: Partial<Course>): Promise<Course> {
    const [course] = await db.update(courses).set(updates).where(eq(courses.id, id)).returning();
    return course;
  }

  // Module methods
  async getModulesByCourse(courseId: number): Promise<Module[]> {
    return await db.select().from(modules).where(eq(modules.courseId, courseId));
  }

  async createModule(insertModule: InsertModule): Promise<Module> {
    const [module] = await db.insert(modules).values(insertModule).returning();
    return module;
  }

  // Quiz methods
  async getQuizzesByCourse(courseId: number): Promise<Quiz[]> {
    return await db.select().from(quizzes).where(eq(quizzes.courseId, courseId));
  }

  async getQuizzesByModule(moduleId: number): Promise<Quiz[]> {
    return await db.select().from(quizzes).where(eq(quizzes.moduleId, moduleId));
  }

  async createQuiz(insertQuiz: InsertQuiz): Promise<Quiz> {
    const [quiz] = await db.insert(quizzes).values(insertQuiz).returning();
    return quiz;
  }

  // Enrollment methods
  async getEnrollment(userId: number, courseId: number): Promise<Enrollment | undefined> {
    const [enrollment] = await db.select().from(enrollments)
      .where(and(eq(enrollments.userId, userId), eq(enrollments.courseId, courseId)));
    return enrollment || undefined;
  }

  async getEnrollmentsByUser(userId: number): Promise<Enrollment[]> {
    return await db.select().from(enrollments).where(eq(enrollments.userId, userId));
  }

  async createEnrollment(insertEnrollment: InsertEnrollment): Promise<Enrollment> {
    const [enrollment] = await db.insert(enrollments).values(insertEnrollment).returning();
    return enrollment;
  }

  // Progress methods
  async getProgress(userId: number, moduleId: number): Promise<Progress | undefined> {
    const [progressRecord] = await db.select().from(progress)
      .where(and(eq(progress.userId, userId), eq(progress.moduleId, moduleId)));
    return progressRecord || undefined;
  }

  async getProgressByCourse(userId: number, courseId: number): Promise<Progress[]> {
    return await db.select().from(progress).where(eq(progress.userId, userId));
  }

  async getProgressByUser(userId: number): Promise<Progress[]> {
    return await db.select().from(progress).where(eq(progress.userId, userId));
  }

  async createProgress(insertProgress: InsertProgress): Promise<Progress> {
    const [progressRecord] = await db.insert(progress).values(insertProgress).returning();
    return progressRecord;
  }

  async updateProgress(id: number, updates: Partial<Progress>): Promise<Progress> {
    const [progressRecord] = await db.update(progress).set(updates).where(eq(progress.id, id)).returning();
    return progressRecord;
  }

  // Quiz attempt methods
  async createQuizAttempt(insertQuizAttempt: InsertQuizAttempt): Promise<QuizAttempt> {
    const [attempt] = await db.insert(quizAttempts).values(insertQuizAttempt).returning();
    return attempt;
  }

  // Certificate methods
  async getCertificatesByUser(userId: number): Promise<Certificate[]> {
    return await db.select().from(certificates).where(eq(certificates.userId, userId));
  }

  // Course material methods
  async getCourseMaterial(id: number): Promise<CourseMaterial | undefined> {
    const [material] = await db.select().from(courseMaterials).where(eq(courseMaterials.id, id));
    return material || undefined;
  }

  async createCourseMaterial(insertCourseMaterial: InsertCourseMaterial): Promise<CourseMaterial> {
    const [material] = await db.insert(courseMaterials).values(insertCourseMaterial).returning();
    return material;
  }

  // Page summary methods
  async getPageSummary(id: number): Promise<PageSummary | undefined> {
    const [summary] = await db.select().from(pageSummaries).where(eq(pageSummaries.id, id));
    return summary || undefined;
  }

  async getPageSummariesByMaterial(materialId: number): Promise<PageSummary[]> {
    return await db.select().from(pageSummaries).where(eq(pageSummaries.materialId, materialId));
  }

  async createPageSummary(insertPageSummary: InsertPageSummary): Promise<PageSummary> {
    const [summary] = await db.insert(pageSummaries).values(insertPageSummary).returning();
    return summary;
  }

  async updatePageSummary(id: number, updates: Partial<PageSummary>): Promise<PageSummary> {
    const [summary] = await db.update(pageSummaries).set(updates).where(eq(pageSummaries.id, id)).returning();
    return summary;
  }

  // Avatar video methods
  async getAvatarVideo(id: number): Promise<AvatarVideo | undefined> {
    const [video] = await db.select().from(avatarVideos).where(eq(avatarVideos.id, id));
    return video || undefined;
  }

  async getAvatarVideosBySummary(summaryId: number): Promise<AvatarVideo[]> {
    return await db.select().from(avatarVideos).where(eq(avatarVideos.summaryId, summaryId));
  }

  async createAvatarVideo(insertAvatarVideo: InsertAvatarVideo): Promise<AvatarVideo> {
    const [video] = await db.insert(avatarVideos).values(insertAvatarVideo).returning();
    return video;
  }

  async updateAvatarVideo(id: number, updates: Partial<AvatarVideo>): Promise<AvatarVideo> {
    const [video] = await db.update(avatarVideos).set(updates).where(eq(avatarVideos.id, id)).returning();
    return video;
  }
}

export const storage = new DatabaseStorage();