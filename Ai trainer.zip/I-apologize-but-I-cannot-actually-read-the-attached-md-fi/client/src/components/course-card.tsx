import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, PlayCircle, Star } from "lucide-react";
import type { Course } from "@shared/schema";

interface CourseCardProps {
  course: Course;
}

export default function CourseCard({ course }: CourseCardProps) {
  const getLevelColor = (level: string) => {
    switch (level?.toLowerCase()) {
      case "beginner": return "bg-primary/10 text-primary";
      case "intermediate": return "bg-secondary/10 text-secondary";
      case "advanced": return "bg-accent/10 text-accent";
      default: return "bg-gray-100 text-gray-600";
    }
  };

  const formatDuration = (hours: number) => {
    if (hours < 1) {
      return `${Math.round(hours * 60)}min`;
    }
    return `${hours}h`;
  };

  return (
    <Link href={`/course/${course.id}`}>
      <Card className="group overflow-hidden hover:shadow-md transition-shadow cursor-pointer">
        <div className="aspect-video bg-gray-200 overflow-hidden">
          {course.thumbnailUrl ? (
            <img 
              src={course.thumbnailUrl} 
              alt={course.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
              <PlayCircle className="text-gray-400" size={48} />
            </div>
          )}
        </div>
        
        <CardContent className="p-5">
          <div className="flex items-center justify-between mb-2">
            <Badge className={`text-xs ${getLevelColor(course.level)}`}>
              {course.level || "Beginner"}
            </Badge>
            <div className="flex items-center">
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    size={14} 
                    className={i < Math.floor(course.rating || 0) ? "fill-current" : ""} 
                  />
                ))}
              </div>
              <span className="text-gray-600 text-sm ml-1">{course.rating || 0}</span>
            </div>
          </div>
          
          <h4 className="font-semibold text-gray-900 mb-2 group-hover:text-primary transition-colors line-clamp-2">
            {course.title}
          </h4>
          <p className="text-gray-600 text-sm mb-3 line-clamp-2">
            {course.shortDescription || course.description}
          </p>
          
          <div className="flex items-center justify-between text-sm text-gray-500">
            <div className="flex items-center">
              <Clock size={14} className="mr-1" />
              <span>{formatDuration(course.estimatedHours || 1)}</span>
            </div>
            <div className="flex items-center">
              <PlayCircle size={14} className="mr-1" />
              <span>Multiple modules</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
