import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, XCircle, RotateCcw, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import type { Quiz as QuizType, QuizAttempt } from "@shared/schema";

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation?: string;
}

interface QuizProps {
  moduleId: number;
  onComplete?: () => void;
}

export default function Quiz({ moduleId, onComplete }: QuizProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [showResults, setShowResults] = useState(false);
  const [quizAttempt, setQuizAttempt] = useState<QuizAttempt | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: quizzes = [], isLoading } = useQuery<QuizType[]>({
    queryKey: ["/api/modules", moduleId, "quizzes"],
    enabled: !!moduleId,
  });

  const submitQuizMutation = useMutation({
    mutationFn: async (data: { quizId: number; answers: Record<string, number>; score: number; passed: boolean }) => {
      const response = await apiRequest("POST", "/api/quiz-attempts", data);
      return response.json();
    },
    onSuccess: (attempt) => {
      setQuizAttempt(attempt);
      toast({
        title: attempt.passed ? "Quiz Passed!" : "Quiz Failed",
        description: attempt.passed 
          ? `Great job! You scored ${attempt.score}%` 
          : `You scored ${attempt.score}%. You need 70% to pass.`,
        variant: attempt.passed ? "default" : "destructive",
      });
      
      if (attempt.passed) {
        queryClient.invalidateQueries({ queryKey: ["/api/progress"] });
        setTimeout(() => {
          onComplete?.();
        }, 2000);
      }
    },
  });

  const quiz = quizzes[0]; // Assuming one quiz per module
  if (isLoading) {
    return (
      <div className="animate-pulse">
        <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
        <div className="space-y-4">
          <div className="h-4 bg-gray-200 rounded w-full"></div>
          <div className="h-4 bg-gray-200 rounded w-3/4"></div>
          <div className="space-y-2">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-10 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!quiz || !quiz.questions) {
    return (
      <div className="text-center py-8">
        <div className="text-gray-400 text-lg mb-2">No quiz available</div>
        <p className="text-gray-600">This module doesn't have a quiz yet.</p>
        <Button onClick={onComplete} className="mt-4">
          Continue to Next Module
        </Button>
      </div>
    );
  }

  const questions: QuizQuestion[] = Array.isArray(quiz.questions) 
    ? quiz.questions as QuizQuestion[]
    : [];

  if (questions.length === 0) {
    return (
      <div className="text-center py-8">
        <div className="text-gray-400 text-lg mb-2">Quiz not ready</div>
        <p className="text-gray-600">Questions are being prepared for this module.</p>
        <Button onClick={onComplete} className="mt-4">
          Continue to Next Module
        </Button>
      </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];
  const isLastQuestion = currentQuestionIndex === questions.length - 1;
  const hasAnsweredCurrent = selectedAnswers[currentQuestion?.id] !== undefined;
  const allQuestionsAnswered = questions.every(q => selectedAnswers[q.id] !== undefined);

  const handleAnswerSelect = (questionId: string, answerIndex: number) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: answerIndex
    }));
  };

  const handleNext = () => {
    if (!hasAnsweredCurrent) {
      toast({
        title: "Please select an answer",
        description: "You must choose an answer before proceeding.",
        variant: "destructive",
      });
      return;
    }

    if (isLastQuestion) {
      handleSubmitQuiz();
    } else {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const calculateScore = () => {
    let correct = 0;
    questions.forEach(question => {
      if (selectedAnswers[question.id] === question.correctAnswer) {
        correct++;
      }
    });
    return Math.round((correct / questions.length) * 100);
  };

  const handleSubmitQuiz = async () => {
    if (!allQuestionsAnswered) {
      toast({
        title: "Incomplete quiz",
        description: "Please answer all questions before submitting.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    const score = calculateScore();
    const passed = score >= (quiz.passingScore || 70);

    try {
      await submitQuizMutation.mutateAsync({
        quizId: quiz.id,
        answers: selectedAnswers,
        score,
        passed,
      });
      setShowResults(true);
    } catch (error) {
      toast({
        title: "Submission failed",
        description: "There was an error submitting your quiz. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRetry = () => {
    setCurrentQuestionIndex(0);
    setSelectedAnswers({});
    setShowResults(false);
    setQuizAttempt(null);
  };

  const getQuestionStatus = (questionIndex: number) => {
    const question = questions[questionIndex];
    const userAnswer = selectedAnswers[question.id];
    
    if (!showResults || userAnswer === undefined) {
      return null;
    }
    
    return userAnswer === question.correctAnswer ? 'correct' : 'incorrect';
  };

  if (showResults && quizAttempt) {
    return (
      <div className="space-y-6">
        <div className="text-center">
          <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full mb-4 ${
            quizAttempt.passed ? 'bg-secondary/10' : 'bg-destructive/10'
          }`}>
            {quizAttempt.passed ? (
              <CheckCircle className="text-secondary" size={32} />
            ) : (
              <XCircle className="text-destructive" size={32} />
            )}
          </div>
          <h2 className="text-2xl font-bold mb-2">
            {quizAttempt.passed ? "Congratulations!" : "Keep Trying!"}
          </h2>
          <p className="text-gray-600 mb-4">
            You scored {quizAttempt.score}% on this quiz.
          </p>
          <div className="flex items-center justify-center space-x-2 mb-6">
            <span className="text-sm text-gray-600">Passing score:</span>
            <span className="font-medium">{quiz.passingScore || 70}%</span>
          </div>
        </div>

        {/* Results Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Quiz Results</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {questions.map((question, index) => {
              const userAnswer = selectedAnswers[question.id];
              const isCorrect = userAnswer === question.correctAnswer;
              
              return (
                <div key={question.id} className="border-b border-gray-200 pb-4 last:border-b-0">
                  <div className="flex items-start space-x-3">
                    <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-sm font-medium ${
                      isCorrect ? 'bg-secondary text-white' : 'bg-destructive text-white'
                    }`}>
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900 mb-2">{question.question}</p>
                      <div className="space-y-1 text-sm">
                        <div className={`p-2 rounded ${isCorrect ? 'bg-secondary/10' : 'bg-destructive/10'}`}>
                          <span className="font-medium">Your answer: </span>
                          {question.options[userAnswer]}
                        </div>
                        {!isCorrect && (
                          <div className="p-2 rounded bg-secondary/10">
                            <span className="font-medium">Correct answer: </span>
                            {question.options[question.correctAnswer]}
                          </div>
                        )}
                        {question.explanation && (
                          <div className="p-2 rounded bg-gray-50">
                            <span className="font-medium">Explanation: </span>
                            {question.explanation}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>

        <div className="flex justify-center space-x-4">
          {quizAttempt.passed ? (
            <Button onClick={onComplete} size="lg">
              Continue to Next Module
              <ArrowRight className="ml-2" size={16} />
            </Button>
          ) : (
            <Button onClick={handleRetry} variant="outline" size="lg">
              <RotateCcw className="mr-2" size={16} />
              Retry Quiz
            </Button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">{quiz.title}</h3>
        <div className="flex items-center space-x-4 text-sm text-gray-600">
          <span>Question {currentQuestionIndex + 1} of {questions.length}</span>
          <span>Passing score: {quiz.passingScore || 70}%</span>
        </div>
      </div>

      {/* Progress Bar */}
      <Progress value={((currentQuestionIndex + 1) / questions.length) * 100} className="h-2" />

      {/* Question Card */}
      <Card>
        <CardContent className="p-6">
          <h4 className="text-lg font-medium text-gray-900 mb-6">
            {currentQuestion?.question}
          </h4>

          <RadioGroup
            value={selectedAnswers[currentQuestion?.id]?.toString() || ""}
            onValueChange={(value) => handleAnswerSelect(currentQuestion.id, parseInt(value))}
          >
            <div className="space-y-3">
              {currentQuestion?.options.map((option, index) => (
                <div key={index} className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                  <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                  <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                    {option}
                  </Label>
                </div>
              ))}
            </div>
          </RadioGroup>
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex items-center justify-between">
        <Button
          variant="outline"
          onClick={handlePrevious}
          disabled={currentQuestionIndex === 0}
        >
          Previous
        </Button>

        <div className="flex space-x-2">
          {questions.map((_, index) => (
            <div
              key={index}
              className={`w-3 h-3 rounded-full ${
                index === currentQuestionIndex
                  ? 'bg-primary'
                  : index < currentQuestionIndex
                  ? 'bg-secondary'
                  : 'bg-gray-200'
              }`}
            />
          ))}
        </div>

        <Button
          onClick={handleNext}
          disabled={!hasAnsweredCurrent || isSubmitting}
        >
          {isSubmitting ? (
            "Submitting..."
          ) : isLastQuestion ? (
            "Submit Quiz"
          ) : (
            "Next"
          )}
          {!isLastQuestion && <ArrowRight className="ml-2" size={16} />}
        </Button>
      </div>

      {/* Quiz Instructions */}
      <div className="text-center text-sm text-gray-600 bg-gray-50 p-4 rounded-lg">
        <p>
          Answer all questions to complete the quiz. You need {quiz.passingScore || 70}% to pass.
          {!quizAttempt && " You can retry if you don't pass on the first attempt."}
        </p>
      </div>
    </div>
  );
}
