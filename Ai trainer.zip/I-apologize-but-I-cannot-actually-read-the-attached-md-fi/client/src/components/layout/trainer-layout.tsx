import { Switch, Route, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useEffect } from "react";
import Header from "./header";
import { Button } from "@/components/ui/button";
import { Upload, Bot, Video, PuzzleIcon, BarChart3 } from "lucide-react";
import ContentUpload from "@/pages/trainer/content-upload";
import AISummary from "@/pages/trainer/ai-summary";
import AvatarVideo from "@/pages/trainer/avatar-video";
import CourseBuilder from "@/pages/trainer/course-builder";
import Analytics from "@/pages/trainer/analytics";
import Login from "@/pages/auth/login";

export default function TrainerLayout() {
  const { user, isLoading } = useAuth();
  const [location, navigate] = useLocation();

  useEffect(() => {
    if (!isLoading && (!user || user.role !== "trainer")) {
      navigate("/login");
    }
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user || user.role !== "trainer") {
    return <Login />;
  }

  const currentPage = location.split("/")[2] || "content-upload";

  const handleNavigation = (page: string) => {
    navigate(`/trainer/${page}`);
  };

  const navItems = [
    { id: "content-upload", label: "Content Upload", icon: Upload },
    { id: "ai-summary", label: "AI Summarization", icon: Bot },
    { id: "avatar-video", label: "Avatar & Video", icon: Video },
    { id: "course-builder", label: "Course Builder", icon: PuzzleIcon },
    { id: "analytics", label: "Analytics", icon: BarChart3 },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="flex">
        {/* Trainer Sidebar Navigation */}
        <nav className="w-64 bg-white border-r border-gray-200 min-h-screen">
          <div className="p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-6">Trainer Dashboard</h2>
            
            <ul className="space-y-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentPage === item.id;
                
                return (
                  <li key={item.id}>
                    <Button
                      variant={isActive ? "secondary" : "ghost"}
                      className={`w-full justify-start ${isActive ? "bg-primary/10 text-primary" : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"}`}
                      onClick={() => handleNavigation(item.id)}
                    >
                      <Icon size={16} className="mr-3" />
                      {item.label}
                    </Button>
                  </li>
                );
              })}
            </ul>
          </div>
        </nav>

        {/* Trainer Main Content */}
        <main className="flex-1 p-8">
          <Switch>
            <Route path="/trainer" component={ContentUpload} />
            <Route path="/trainer/content-upload" component={ContentUpload} />
            <Route path="/trainer/ai-summary" component={AISummary} />
            <Route path="/trainer/avatar-video" component={AvatarVideo} />
            <Route path="/trainer/course-builder" component={CourseBuilder} />
            <Route path="/trainer/analytics" component={Analytics} />
          </Switch>
        </main>
      </div>
    </div>
  );
}
