import { Switch, Route, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useEffect } from "react";
import Header from "./header";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Home, BarChart3, BookOpen, Award } from "lucide-react";
import HomePage from "@/pages/learner/home";
import Dashboard from "@/pages/learner/dashboard";
import Learning from "@/pages/learner/learning";
import Certificates from "@/pages/learner/certificates";
import CourseDetail from "@/pages/learner/course-detail";
import Login from "@/pages/auth/login";

export default function LearnerLayout() {
  const { user, isLoading } = useAuth();
  const [location, navigate] = useLocation();

  useEffect(() => {
    if (!isLoading && !user) {
      navigate("/login");
    } else if (user && user.role === 'trainer') {
      navigate("/trainer");
    }
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  const currentTab = location === "/" ? "home" : 
                   location === "/dashboard" ? "dashboard" :
                   location === "/learning" ? "learning" :
                   location === "/certificates" ? "certificates" : "home";

  const handleTabChange = (tab: string) => {
    const routes = {
      home: "/",
      dashboard: "/dashboard", 
      learning: "/learning",
      certificates: "/certificates"
    };
    navigate(routes[tab as keyof typeof routes]);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <Switch>
        <Route path="/course/:id">
          <CourseDetail />
        </Route>
        <Route>
          {/* Learner Navigation Tabs */}
          <nav className="bg-white border-b border-gray-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <Tabs value={currentTab} onValueChange={handleTabChange}>
                <TabsList className="h-auto p-0 bg-transparent">
                  <TabsTrigger 
                    value="home" 
                    className="flex items-center space-x-2 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary py-4 px-4 text-sm font-medium"
                  >
                    <Home size={16} />
                    <span>Home</span>
                  </TabsTrigger>
                  <TabsTrigger 
                    value="dashboard"
                    className="flex items-center space-x-2 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary py-4 px-4 text-sm font-medium"
                  >
                    <BarChart3 size={16} />
                    <span>My Dashboard</span>
                  </TabsTrigger>
                  <TabsTrigger 
                    value="learning"
                    className="flex items-center space-x-2 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary py-4 px-4 text-sm font-medium"
                  >
                    <BookOpen size={16} />
                    <span>My Learning</span>
                  </TabsTrigger>
                  <TabsTrigger 
                    value="certificates"
                    className="flex items-center space-x-2 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary py-4 px-4 text-sm font-medium"
                  >
                    <Award size={16} />
                    <span>Certificates</span>
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </nav>

          {/* Tab Content */}
          <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <Switch>
              <Route path="/" component={HomePage} />
              <Route path="/dashboard" component={Dashboard} />
              <Route path="/learning" component={Learning} />
              <Route path="/certificates" component={Certificates} />
            </Switch>
          </main>
        </Route>
      </Switch>
    </div>
  );
}