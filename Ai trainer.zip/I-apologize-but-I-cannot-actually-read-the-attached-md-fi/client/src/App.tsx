import { Router, Route, Switch } from "wouter";
import { AuthProvider, useAuth } from "@/hooks/use-auth";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { queryClient } from "@/lib/queryClient";

// Auth pages
import Login from "@/pages/auth/login";
import Register from "@/pages/auth/register";

// Learner pages
import LearnerLayout from "@/components/layout/learner-layout";
import Home from "@/pages/learner/home";
import Dashboard from "@/pages/learner/dashboard";
import Learning from "@/pages/learner/learning";
import CourseDetail from "@/pages/learner/course-detail";
import Certificates from "@/pages/learner/certificates";

// Trainer pages
import TrainerLayout from "@/components/layout/trainer-layout";
import ContentUpload from "@/pages/trainer/content-upload";
import AiSummary from "@/pages/trainer/ai-summary";
import AvatarVideo from "@/pages/trainer/avatar-video";
import CourseBuilder from "@/pages/trainer/course-builder";
import Analytics from "@/pages/trainer/analytics";

import NotFound from "@/pages/not-found";

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <AppContent />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

function AppContent() {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <Router>
        <Switch>
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          <Route path="/" component={Login} />
          <Route component={Login} />
        </Switch>
      </Router>
    );
  }

  // Universal router - handles both learner and trainer routes
  return (
    <Router>
      <Switch>
        {/* Auth routes */}
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />

        {/* Trainer routes */}
        <Route path="/trainer/:page?" component={TrainerLayout} />

        {/* Learner routes (default) */}
        <Route path="/" component={LearnerLayout} />
        <Route path="/dashboard" component={LearnerLayout} />
        <Route path="/learning" component={LearnerLayout} />
        <Route path="/course/:id" component={LearnerLayout} />
        <Route path="/certificates" component={LearnerLayout} />

        <Route component={NotFound} />
      </Switch>
    </Router>
  );
}

export default App;