import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { GripVertical, Plus, Edit, Trash2, Play, PuzzleIcon, CheckCircle, Eye } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import type { Course, Module, Quiz } from "@shared/schema";

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
}

interface ModuleWithQuiz extends Module {
  quiz?: Quiz;
  hasVideo: boolean;
}

export default function CourseBuilder() {
  const [selectedCourse, setSelectedCourse] = useState<string>("");
  const [isModuleDialogOpen, setIsModuleDialogOpen] = useState(false);
  const [isQuizDialogOpen, setIsQuizDialogOpen] = useState(false);
  const [editingModule, setEditingModule] = useState<ModuleWithQuiz | null>(null);
  const [editingQuiz, setEditingQuiz] = useState<Quiz | null>(null);
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  const [newModule, setNewModule] = useState({
    title: "",
    description: "",
    videoUrl: "",
    videoDuration: 0,
  });

  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
    queryParams: { trainerId: user?.id },
    enabled: !!user,
  });

  const { data: modules = [] } = useQuery<ModuleWithQuiz[]>({
    queryKey: ["/api/courses", selectedCourse, "modules"],
    enabled: !!selectedCourse,
  });

  const selectedCourseData = courses.find(c => c.id.toString() === selectedCourse);

  // Mock modules with video and quiz status for demo
  const mockModules: ModuleWithQuiz[] = [
    {
      id: 1,
      courseId: parseInt(selectedCourse) || 1,
      title: "Introduction to React",
      description: "Learn the basics of React and component-based development",
      videoUrl: "https://example.com/video1.mp4",
      videoDuration: 900, // 15 minutes
      orderIndex: 1,
      createdAt: new Date(),
      hasVideo: true,
      quiz: {
        id: 1,
        moduleId: 1,
        courseId: parseInt(selectedCourse) || 1,
        title: "React Basics Quiz",
        questions: [],
        passingScore: 70,
        type: "module",
        createdAt: new Date(),
      }
    },
    {
      id: 2,
      courseId: parseInt(selectedCourse) || 1,
      title: "Components and JSX",
      description: "Understanding React components and JSX syntax",
      videoUrl: "https://example.com/video2.mp4",
      videoDuration: 1200, // 20 minutes
      orderIndex: 2,
      createdAt: new Date(),
      hasVideo: true,
    },
    {
      id: 3,
      courseId: parseInt(selectedCourse) || 1,
      title: "State Management",
      description: "Learn about React state and event handling",
      videoUrl: null,
      videoDuration: null,
      orderIndex: 3,
      createdAt: new Date(),
      hasVideo: false,
    }
  ];

  const createModuleMutation = useMutation({
    mutationFn: async (moduleData: any) => {
      const response = await apiRequest("POST", `/api/courses/${selectedCourse}/modules`, moduleData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Module created!",
        description: "New module has been added to the course.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/courses", selectedCourse, "modules"] });
      setIsModuleDialogOpen(false);
      resetModuleForm();
    },
  });

  const createQuizMutation = useMutation({
    mutationFn: async (quizData: any) => {
      const response = await apiRequest("POST", "/api/quizzes", quizData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Quiz created!",
        description: "Quiz has been added to the module.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/courses", selectedCourse, "modules"] });
      setIsQuizDialogOpen(false);
      setQuizQuestions([]);
    },
  });

  const publishCourseMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("PUT", `/api/courses/${selectedCourse}`, {
        status: "published"
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Course published!",
        description: "Your course is now live and available to learners.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
    },
  });

  const handleDragEnd = (result: any) => {
    if (!result.destination) return;

    const items = Array.from(mockModules);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    // Update order indexes
    items.forEach((item, index) => {
      item.orderIndex = index + 1;
    });

    // In real implementation, save the new order to backend
    toast({
      title: "Module order updated",
      description: "The module order has been saved.",
    });
  };

  const resetModuleForm = () => {
    setNewModule({
      title: "",
      description: "",
      videoUrl: "",
      videoDuration: 0,
    });
    setEditingModule(null);
  };

  const handleCreateModule = () => {
    createModuleMutation.mutate({
      ...newModule,
      orderIndex: mockModules.length + 1,
    });
  };

  const handleCreateQuiz = () => {
    if (!editingModule) return;

    createQuizMutation.mutate({
      moduleId: editingModule.id,
      courseId: parseInt(selectedCourse),
      title: `${editingModule.title} Quiz`,
      questions: quizQuestions,
      passingScore: 70,
      type: "module",
    });
  };

  const addQuestion = () => {
    const newQuestion: QuizQuestion = {
      id: `q_${Date.now()}`,
      question: "",
      options: ["", "", "", ""],
      correctAnswer: 0,
    };
    setQuizQuestions([...quizQuestions, newQuestion]);
  };

  const updateQuestion = (index: number, field: string, value: any) => {
    const updated = [...quizQuestions];
    if (field === "options") {
      updated[index] = { ...updated[index], options: value };
    } else {
      updated[index] = { ...updated[index], [field]: value };
    }
    setQuizQuestions(updated);
  };

  const removeQuestion = (index: number) => {
    setQuizQuestions(quizQuestions.filter((_, i) => i !== index));
  };

  const canPublish = selectedCourseData && mockModules.length > 0 && mockModules.every(m => m.hasVideo);

  return (
    <div className="max-w-6xl">
      <h2 className="text-2xl font-semibold text-gray-900 mb-2">Course Builder</h2>
      <p className="text-gray-600 mb-8">Organize your content into structured modules and create interactive assessments</p>

      {/* Course Selection */}
      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex-1 max-w-md">
              <Label htmlFor="course-select">Select Course</Label>
              <Select value={selectedCourse} onValueChange={setSelectedCourse}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a course to build" />
                </SelectTrigger>
                <SelectContent>
                  {courses.map((course) => (
                    <SelectItem key={course.id} value={course.id.toString()}>
                      {course.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedCourse && (
              <div className="flex items-center space-x-4">
                <Badge variant={selectedCourseData?.status === "published" ? "default" : "secondary"}>
                  {selectedCourseData?.status || "draft"}
                </Badge>
                <Button
                  onClick={() => publishCourseMutation.mutate()}
                  disabled={!canPublish || publishCourseMutation.isPending}
                  variant={canPublish ? "default" : "outline"}
                >
                  {selectedCourseData?.status === "published" ? "Published" : "Publish Course"}
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {selectedCourse && (
        <>
          {/* Course Overview */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>{selectedCourseData?.title}</CardTitle>
              <CardDescription>{selectedCourseData?.description}</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Modules</p>
                  <p className="text-lg font-semibold">{mockModules.length}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Videos</p>
                  <p className="text-lg font-semibold">{mockModules.filter(m => m.hasVideo).length}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Quizzes</p>
                  <p className="text-lg font-semibold">{mockModules.filter(m => m.quiz).length}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Total Duration</p>
                  <p className="text-lg font-semibold">
                    {Math.floor(mockModules.reduce((total, m) => total + (m.videoDuration || 0), 0) / 60)}min
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Module Management */}
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Course Modules</CardTitle>
                <Button onClick={() => setIsModuleDialogOpen(true)}>
                  <Plus className="mr-2" size={16} />
                  Add Module
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              {mockModules.length > 0 ? (
                <DragDropContext onDragEnd={handleDragEnd}>
                  <Droppable droppableId="modules">
                    {(provided) => (
                      <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-4">
                        {mockModules
                          .sort((a, b) => a.orderIndex - b.orderIndex)
                          .map((module, index) => (
                            <Draggable key={module.id} draggableId={module.id.toString()} index={index}>
                              {(provided) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.draggableProps}
                                  className="bg-gray-50 border border-gray-200 rounded-lg p-4"
                                >
                                  <div className="flex items-center space-x-4">
                                    <div
                                      {...provided.dragHandleProps}
                                      className="text-gray-400 hover:text-gray-600 cursor-grab"
                                    >
                                      <GripVertical size={20} />
                                    </div>
                                    
                                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white text-sm font-medium">
                                      {module.orderIndex}
                                    </div>
                                    
                                    <div className="flex-1">
                                      <div className="flex items-center space-x-2 mb-1">
                                        <h4 className="font-medium text-gray-900">{module.title}</h4>
                                        {module.hasVideo && (
                                          <Badge variant="secondary" className="text-xs">
                                            <Play className="mr-1" size={10} />
                                            Video
                                          </Badge>
                                        )}
                                        {module.quiz && (
                                          <Badge variant="outline" className="text-xs">
                                            <CheckCircle className="mr-1" size={10} />
                                            Quiz
                                          </Badge>
                                        )}
                                      </div>
                                      <p className="text-sm text-gray-600">{module.description}</p>
                                      {module.videoDuration && (
                                        <p className="text-xs text-gray-500 mt-1">
                                          Duration: {Math.floor(module.videoDuration / 60)}:{(module.videoDuration % 60).toString().padStart(2, '0')}
                                        </p>
                                      )}
                                    </div>
                                    
                                    <div className="flex items-center space-x-2">
                                      {!module.quiz && (
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          onClick={() => {
                                            setEditingModule(module);
                                            setIsQuizDialogOpen(true);
                                          }}
                                        >
                                          Add Quiz
                                        </Button>
                                      )}
                                      <Button variant="outline" size="sm">
                                        <Edit size={14} />
                                      </Button>
                                      <Button variant="outline" size="sm">
                                        <Eye size={14} />
                                      </Button>
                                    </div>
                                  </div>
                                </div>
                              )}
                            </Draggable>
                          ))}
                        {provided.placeholder}
                      </div>
                    )}
                  </Droppable>
                </DragDropContext>
              ) : (
                <div className="text-center py-12 text-gray-500">
                  <PuzzleIcon size={48} className="mx-auto mb-4 text-gray-300" />
                  <p className="text-lg font-medium mb-2">No modules yet</p>
                  <p className="text-sm">Add your first module to start building the course structure</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Course Publishing Requirements */}
          <Card>
            <CardHeader>
              <CardTitle>Publishing Requirements</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <CheckCircle className={`${mockModules.length > 0 ? 'text-secondary' : 'text-gray-300'}`} size={20} />
                  <span className={mockModules.length > 0 ? 'text-gray-900' : 'text-gray-500'}>
                    At least one module ({mockModules.length} created)
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className={`${mockModules.every(m => m.hasVideo) && mockModules.length > 0 ? 'text-secondary' : 'text-gray-300'}`} size={20} />
                  <span className={mockModules.every(m => m.hasVideo) && mockModules.length > 0 ? 'text-gray-900' : 'text-gray-500'}>
                    All modules have videos ({mockModules.filter(m => m.hasVideo).length}/{mockModules.length})
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className={`${selectedCourseData?.description ? 'text-secondary' : 'text-gray-300'}`} size={20} />
                  <span className={selectedCourseData?.description ? 'text-gray-900' : 'text-gray-500'}>
                    Course description provided
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {/* Add Module Dialog */}
      <Dialog open={isModuleDialogOpen} onOpenChange={setIsModuleDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Add New Module</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="module-title">Module Title</Label>
              <Input
                id="module-title"
                placeholder="e.g., Introduction to React Components"
                value={newModule.title}
                onChange={(e) => setNewModule(prev => ({ ...prev, title: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="module-description">Description</Label>
              <Textarea
                id="module-description"
                placeholder="Describe what students will learn in this module..."
                value={newModule.description}
                onChange={(e) => setNewModule(prev => ({ ...prev, description: e.target.value }))}
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="video-url">Video URL (optional)</Label>
                <Input
                  id="video-url"
                  placeholder="https://example.com/video.mp4"
                  value={newModule.videoUrl}
                  onChange={(e) => setNewModule(prev => ({ ...prev, videoUrl: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="video-duration">Duration (seconds)</Label>
                <Input
                  id="video-duration"
                  type="number"
                  placeholder="900"
                  value={newModule.videoDuration}
                  onChange={(e) => setNewModule(prev => ({ ...prev, videoDuration: parseInt(e.target.value) || 0 }))}
                />
              </div>
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => { setIsModuleDialogOpen(false); resetModuleForm(); }}>
                Cancel
              </Button>
              <Button
                onClick={handleCreateModule}
                disabled={!newModule.title || createModuleMutation.isPending}
              >
                {createModuleMutation.isPending ? "Creating..." : "Create Module"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Quiz Dialog */}
      <Dialog open={isQuizDialogOpen} onOpenChange={setIsQuizDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create Quiz for: {editingModule?.title}</DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            {quizQuestions.map((question, index) => (
              <Card key={question.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-4">
                    <h4 className="font-medium">Question {index + 1}</h4>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeQuestion(index)}
                    >
                      <Trash2 size={14} />
                    </Button>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <Label>Question</Label>
                      <Textarea
                        placeholder="Enter your question..."
                        value={question.question}
                        onChange={(e) => updateQuestion(index, "question", e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <Label>Answer Options</Label>
                      <div className="space-y-2">
                        {question.options.map((option, optionIndex) => (
                          <div key={optionIndex} className="flex items-center space-x-2">
                            <input
                              type="radio"
                              name={`correct-${question.id}`}
                              checked={question.correctAnswer === optionIndex}
                              onChange={() => updateQuestion(index, "correctAnswer", optionIndex)}
                            />
                            <Input
                              placeholder={`Option ${optionIndex + 1}`}
                              value={option}
                              onChange={(e) => {
                                const newOptions = [...question.options];
                                newOptions[optionIndex] = e.target.value;
                                updateQuestion(index, "options", newOptions);
                              }}
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            
            <Button onClick={addQuestion} variant="outline" className="w-full">
              <Plus className="mr-2" size={16} />
              Add Question
            </Button>
            
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => { setIsQuizDialogOpen(false); setQuizQuestions([]); }}>
                Cancel
              </Button>
              <Button
                onClick={handleCreateQuiz}
                disabled={quizQuestions.length === 0 || createQuizMutation.isPending}
              >
                {createQuizMutation.isPending ? "Creating..." : "Create Quiz"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {!selectedCourse && (
        <Card>
          <CardContent className="p-12 text-center">
            <PuzzleIcon size={64} className="mx-auto mb-4 text-gray-300" />
            <h3 className="text-xl font-medium text-gray-900 mb-2">Course Builder</h3>
            <p className="text-gray-600">Select a course to start organizing content into modules and assessments</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
