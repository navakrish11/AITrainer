import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Play, Download, User, Video, Eye, CheckCircle2, Upload, Share2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

interface AvatarOption {
  id: number;
  name: string;
  image: string;
  voice: string;
  description: string;
  specialty: string;
  isSelected: boolean;
}

interface VideoProgress {
  pageNumber: number;
  title: string;
  status: 'pending' | 'generating' | 'completed' | 'published';
  progress: number;
  videoUrl: string | null;
  duration: string;
}

export default function AvatarVideoGeneration() {
  const [selectedAvatar, setSelectedAvatar] = useState<number | null>(null);
  const [approvedPages, setApprovedPages] = useState<any[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showPublishOptions, setShowPublishOptions] = useState(false);
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  // Hardcoded avatars for medical content
  const [avatars, setAvatars] = useState<AvatarOption[]>([
    {
      id: 1,
      name: "Dr. Sarah Chen",
      image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&h=200&fit=crop&crop=face",
      voice: "Professional Female Voice",
      description: "Cardiology Specialist",
      specialty: "Cardiovascular Medicine",
      isSelected: false,
    },
    {
      id: 2,
      name: "Dr. Michael Rodriguez",
      image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&crop=face",
      voice: "Clear Male Voice",
      description: "Internal Medicine Physician",
      specialty: "General Medicine",
      isSelected: false,
    },
    {
      id: 3,
      name: "Dr. Emily Johnson",
      image: "https://images.unsplash.com/photo-1594824717903-48fcef64b61e?w=200&h=200&fit=crop&crop=face",
      voice: "Warm Female Voice",
      description: "Medical Educator",
      specialty: "Medical Education",
      isSelected: false,
    },
    {
      id: 4,
      name: "Dr. James Park",
      image: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=200&h=200&fit=crop&crop=face",
      voice: "Authoritative Male Voice",
      description: "Cardiac Surgeon",
      specialty: "Cardiovascular Surgery",
      isSelected: false,
    },
    {
      id: 5,
      name: "Dr. Lisa Thompson",
      image: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=200&h=200&fit=crop&crop=face",
      voice: "Friendly Female Voice",
      description: "Preventive Medicine Specialist",
      specialty: "Preventive Care",
      isSelected: false,
    },
  ]);

  // Mock video progress for each page
  const [videoProgress, setVideoProgress] = useState<VideoProgress[]>([]);

  useEffect(() => {
    // Load approved pages from sessionStorage
    const storedPages = sessionStorage.getItem('approvedPages');
    if (storedPages) {
      const pages = JSON.parse(storedPages);
      setApprovedPages(pages);

      // Initialize video progress
      setVideoProgress(pages.map((page: any) => ({
        pageNumber: page.pageNumber,
        title: page.title,
        status: 'pending' as const,
        progress: 0,
        videoUrl: null,
        duration: "0:00",
      })));
    }
  }, []);

  const handleAvatarSelect = (avatarId: number) => {
    setAvatars(prev => prev.map(avatar => ({
      ...avatar,
      isSelected: avatar.id === avatarId
    })));
    setSelectedAvatar(avatarId);

    const selectedAvatarData = avatars.find(a => a.id === avatarId);
    toast({
      title: "Avatar selected!",
      description: `${selectedAvatarData?.name} will present your medical course content.`,
    });
  };

  const generateSingleVideo = async (pageNumber: number) => {
    if (!selectedAvatar) {
      toast({
        title: "No avatar selected",
        description: "Please select an avatar before generating videos.",
        variant: "destructive",
      });
      return;
    }

    // Update status to generating
    setVideoProgress(prev => prev.map(video => 
      video.pageNumber === pageNumber 
        ? { ...video, status: 'generating' as const, progress: 0 }
        : video
    ));

    // Simulate video generation progress
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setVideoProgress(prev => prev.map(video => 
        video.pageNumber === pageNumber 
          ? { ...video, progress: Math.min(progress, 100) }
          : video
      ));

      if (progress >= 100) {
        clearInterval(interval);

        // Generate random duration between 1-2 minutes
        const minutes = Math.floor(Math.random() * 2) + 1;
        const seconds = Math.floor(Math.random() * 60);
        const duration = `${minutes}:${seconds.toString().padStart(2, '0')}`;

        setVideoProgress(prev => prev.map(video => 
          video.pageNumber === pageNumber 
            ? { 
                ...video, 
                status: 'completed' as const, 
                videoUrl: `https://example.com/medical-video-page-${pageNumber}.mp4`,
                duration: duration
              }
            : video
        ));

        toast({
          title: "Video generated!",
          description: `Page ${pageNumber} video is ready (${duration}).`,
        });
      }
    }, 800);
  };

  const generateAllVideos = async () => {
    if (!selectedAvatar) {
      toast({
        title: "No avatar selected",
        description: "Please select an avatar before generating videos.",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);

    // Generate videos for all pages sequentially
    for (let i = 0; i < approvedPages.length; i++) {
      await generateSingleVideo(approvedPages[i].pageNumber);
      // Wait a bit between generations
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    setIsGenerating(false);
    setShowPublishOptions(true);

    toast({
      title: "All videos generated!",
      description: "Your complete medical course is ready for publication.",
    });
  };

  const handlePublishVideo = (pageNumber: number) => {
    setVideoProgress(prev => prev.map(video => 
      video.pageNumber === pageNumber 
        ? { ...video, status: 'published' as const }
        : video
    ));

    toast({
      title: "Video published!",
      description: `Page ${pageNumber} video is now available to learners.`,
    });
  };

  const handlePublishAll = () => {
    const completedVideos = videoProgress.filter(v => v.status === 'completed');

    if (completedVideos.length === 0) {
      toast({
        title: "No videos to publish",
        description: "Generate videos first before publishing.",
        variant: "destructive",
      });
      return;
    }

    setVideoProgress(prev => prev.map(video => 
      video.status === 'completed' 
        ? { ...video, status: 'published' as const }
        : video
    ));

    // Store published course data
    const courseData = {
      title: "Advanced Cardiovascular Medicine",
      videos: videoProgress.filter(v => v.status === 'completed' || v.status === 'published'),
      avatar: avatars.find(a => a.id === selectedAvatar),
      publishedAt: new Date().toISOString(),
    };

    sessionStorage.setItem('publishedCourse', JSON.stringify(courseData));

    toast({
      title: "Course published successfully!",
      description: "Your medical course is now live and available to learners.",
    });

    // Navigate to learner view after publishing
    setTimeout(() => {
      setLocation('/learner/home');
    }, 2000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "text-secondary";
      case "generating": return "text-primary";
      case "published": return "text-purple-600";
      default: return "text-gray-500";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed": return "Ready";
      case "generating": return "Generating...";
      case "published": return "Published";
      default: return "Pending";
    }
  };

  const selectedAvatarData = avatars.find(a => a.id === selectedAvatar);
  const completedCount = videoProgress.filter(v => v.status === 'completed').length;
  const publishedCount = videoProgress.filter(v => v.status === 'published').length;
  const totalPages = approvedPages.length;

  return (
    <div className="max-w-6xl">
      <h2 className="text-2xl font-semibold text-gray-900 mb-2">Medical Course Avatar & Video Generation</h2>
      <p className="text-gray-600 mb-8">Select a medical professional avatar and generate engaging videos from your approved summaries</p>

      {/* Avatar Selection Grid */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Select Medical Professional Avatar</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {avatars.map((avatar) => (
              <div
                key={avatar.id}
                className={`border-2 rounded-lg p-4 text-center cursor-pointer transition-colors ${
                  avatar.isSelected 
                    ? 'border-primary bg-primary/5' 
                    : 'border-gray-200 hover:border-primary hover:bg-primary/5'
                }`}
                onClick={() => handleAvatarSelect(avatar.id)}
              >
                <Avatar className="w-16 h-16 mx-auto mb-3">
                  <AvatarImage src={avatar.image} alt={avatar.name} />
                  <AvatarFallback>
                    <User size={32} />
                  </AvatarFallback>
                </Avatar>
                <p className="text-sm font-medium text-gray-900">{avatar.name}</p>
                <p className="text-xs text-gray-600 mb-1">{avatar.description}</p>
                <p className="text-xs text-blue-600 mb-2">{avatar.specialty}</p>
                <p className="text-xs text-gray-500 mb-3">{avatar.voice}</p>
                <Badge variant={avatar.isSelected ? "default" : "secondary"} className="text-xs">
                  {avatar.isSelected ? "Selected" : "Select"}
                </Badge>
              </div>
            ))}
          </div>

          {selectedAvatarData && (
            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <Avatar className="w-12 h-12">
                  <AvatarImage src={selectedAvatarData.image} alt={selectedAvatarData.name} />
                  <AvatarFallback><User size={24} /></AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium text-blue-900">{selectedAvatarData.name} Selected</p>
                  <p className="text-sm text-blue-700">{selectedAvatarData.specialty} • {selectedAvatarData.voice}</p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Video Generation Progress */}
      <Card className="mb-6">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Video Generation Progress</CardTitle>
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-600">
                {completedCount} of {totalPages} completed • {publishedCount} published
              </div>
              <Button
                onClick={generateAllVideos}
                disabled={isGenerating || !selectedAvatar}
                size="lg"
              >
                <Play className="mr-2" size={16} />
                {isGenerating ? 'Generating All Videos...' : 'Generate All Videos'}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            {approvedPages.map((page, index) => {
              const progress = videoProgress.find(v => v.pageNumber === page.pageNumber) || {
                pageNumber: page.pageNumber,
                title: page.title,
                status: "pending" as const,
                progress: 0,
                videoUrl: null,
                duration: "0:00",
              };

              return (
                <div key={page.pageNumber} className="flex items-center p-4 bg-gray-50 rounded-lg">
                  <div className="w-12 h-8 bg-white rounded mr-4 flex items-center justify-center border">
                    {progress.status === "completed" || progress.status === "published" ? (
                      <Video className="text-secondary" size={16} />
                    ) : progress.status === "generating" ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
                    ) : (
                      <Video className="text-gray-400" size={16} />
                    )}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="font-medium text-gray-900">Page {page.pageNumber}: {page.title}</p>
                        <p className="text-sm text-gray-600">{page.summary.substring(0, 60)}...</p>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className={`text-sm font-medium ${getStatusColor(progress.status)}`}>
                          {getStatusText(progress.status)}
                        </span>
                        {progress.duration !== "0:00" && (
                          <Badge variant="outline" className="text-xs">
                            {progress.duration}
                          </Badge>
                        )}
                      </div>
                    </div>

                    {progress.status === "generating" && (
                      <Progress value={progress.progress} className="h-2 mb-2" />
                    )}
                  </div>

                  <div className="ml-4 flex items-center space-x-2">
                    {(progress.status === "completed" || progress.status === "published") && (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          title="Preview Video"
                        >
                          <Eye size={16} />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          title="Download Video"
                        >
                          <Download size={16} />
                        </Button>
                      </>
                    )}

                    {progress.status === "completed" && (
                      <Button
                        size="sm"
                        onClick={() => handlePublishVideo(page.pageNumber)}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        <Upload size={16} className="mr-1" />
                        Publish
                      </Button>
                    )}

                    {progress.status === "published" && (
                      <Badge className="bg-purple-100 text-purple-700">
                        <CheckCircle2 size={12} className="mr-1" />
                        Live
                      </Badge>
                    )}

                    {progress.status === "pending" && selectedAvatar && (
                      <Button
                        size="sm"
                        onClick={() => generateSingleVideo(page.pageNumber)}
                        disabled={isGenerating}
                      >
                        <Play size={16} />
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}

            {approvedPages.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Video size={48} className="mx-auto mb-4 text-gray-300" />
                <p className="text-lg font-medium mb-2">No approved content found</p>
                <p className="text-sm">Complete the AI summarization step first to generate videos</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Publish All Button */}
      {(completedCount > 0 || showPublishOptions) && (
        <div className="text-center">
          <Button
            size="lg"
            onClick={handlePublishAll}
            className="bg-purple-600 hover:bg-purple-700 px-8"
            disabled={completedCount === 0}
          >
            <Upload className="mr-2" size={20} />
            Publish All Videos ({completedCount} ready)
          </Button>
          <p className="text-sm text-gray-600 mt-2">
            Published videos will be available to learners immediately
          </p>
        </div>
      )}

      {/* Course Summary */}
      {selectedAvatarData && totalPages > 0 && (
        <Card className="mt-8">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Avatar className="w-12 h-12">
                  <AvatarImage src={selectedAvatarData.image} alt={selectedAvatarData.name} />
                  <AvatarFallback><User size={24} /></AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium text-gray-900">Advanced Cardiovascular Medicine</p>
                  <p className="text-sm text-gray-600">
                    {totalPages} pages • Presented by {selectedAvatarData.name}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600">Course Progress</p>
                <p className="font-medium text-gray-900">
                  {publishedCount > 0 ? `${publishedCount} Published` : `${completedCount} Ready`}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}