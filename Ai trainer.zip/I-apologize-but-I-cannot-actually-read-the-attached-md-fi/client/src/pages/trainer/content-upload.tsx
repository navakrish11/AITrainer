
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { CloudUpload, FileText, CheckCircle, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import type { Course } from "@shared/schema";

interface UploadState {
  status: 'idle' | 'uploading' | 'processing' | 'completed' | 'error';
  progress: number;
  message: string;
}

// Mock medical content for 5 pages
const mockMedicalContent = [
  {
    pageNumber: 1,
    title: "Introduction to Cardiovascular Medicine",
    content: "Cardiovascular medicine focuses on the diagnosis and treatment of heart and blood vessel disorders. The cardiovascular system consists of the heart, blood vessels, and blood. Common conditions include coronary artery disease, heart failure, arrhythmias, and hypertension. Understanding the anatomy and physiology of the cardiovascular system is essential for effective treatment and prevention strategies.",
    summary: "Introduction to cardiovascular medicine covering heart and blood vessel disorders, including common conditions like coronary artery disease, heart failure, and hypertension."
  },
  {
    pageNumber: 2,
    title: "Diagnostic Procedures in Cardiology",
    content: "Modern cardiology employs various diagnostic techniques including electrocardiography (ECG), echocardiography, cardiac catheterization, and stress testing. ECG measures electrical activity of the heart, while echocardiography uses ultrasound to visualize heart structures. Cardiac catheterization involves inserting a thin tube into blood vessels to assess coronary arteries. Stress testing evaluates heart function during physical exertion.",
    summary: "Overview of cardiac diagnostic procedures including ECG, echocardiography, cardiac catheterization, and stress testing for comprehensive heart evaluation."
  },
  {
    pageNumber: 3,
    title: "Pharmacological Interventions",
    content: "Cardiovascular pharmacology includes medications such as ACE inhibitors, beta-blockers, diuretics, and anticoagulants. ACE inhibitors reduce blood pressure by blocking angiotensin-converting enzyme. Beta-blockers slow heart rate and reduce blood pressure. Diuretics help remove excess fluid from the body. Anticoagulants prevent blood clot formation, reducing stroke and heart attack risk.",
    summary: "Key cardiovascular medications including ACE inhibitors, beta-blockers, diuretics, and anticoagulants, their mechanisms and therapeutic benefits."
  },
  {
    pageNumber: 4,
    title: "Surgical Interventions and Procedures",
    content: "Cardiac surgery encompasses procedures like coronary artery bypass grafting (CABG), valve replacement, and heart transplantation. CABG creates new pathways around blocked arteries using grafts from other blood vessels. Valve replacement involves substituting damaged heart valves with mechanical or biological prostheses. Heart transplantation is considered for end-stage heart failure when other treatments have failed.",
    summary: "Major cardiac surgical procedures including CABG, valve replacement, and heart transplantation for treating severe cardiovascular conditions."
  },
  {
    pageNumber: 5,
    title: "Prevention and Lifestyle Management",
    content: "Cardiovascular disease prevention involves lifestyle modifications including regular exercise, healthy diet, smoking cessation, and stress management. Exercise strengthens the heart muscle and improves circulation. A diet low in saturated fat and high in fruits and vegetables reduces cardiovascular risk. Smoking cessation immediately begins to reduce heart disease risk. Stress management techniques help control blood pressure and heart rate.",
    summary: "Cardiovascular disease prevention through lifestyle changes: regular exercise, healthy diet, smoking cessation, and stress management techniques."
  }
];

export default function ContentUpload() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadState, setUploadState] = useState<UploadState>({
    status: 'idle',
    progress: 0,
    message: ''
  });
  const [courseData, setCourseData] = useState({
    title: '',
    description: '',
    domain: '',
    level: 'beginner' as const,
    estimatedHours: 1,
  });

  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type !== 'application/pdf') {
        toast({
          title: "Invalid file type",
          description: "Please select a PDF file.",
          variant: "destructive",
        });
        return;
      }
      setSelectedFile(file);
      setUploadState({ status: 'idle', progress: 0, message: '' });
    }
  };

  const handleDrop = (event: React.DragEvent) => {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    if (file) {
      const input = document.createElement('input');
      input.type = 'file';
      input.files = event.dataTransfer.files;
      handleFileSelect({ target: input } as any);
    }
  };

  const handleDragOver = (event: React.DragEvent) => {
    event.preventDefault();
  };

  const handleUpload = async () => {
    if (!selectedFile || !courseData.title) {
      toast({
        title: "Missing information",
        description: "Please provide course details and select a file.",
        variant: "destructive",
      });
      return;
    }

    // Mock upload process with medical content
    setUploadState({ status: 'uploading', progress: 20, message: 'Uploading PDF...' });
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    setUploadState({ status: 'processing', progress: 60, message: 'Processing medical content...' });
    
    await new Promise(resolve => setTimeout(resolve, 1500));
    setUploadState({ status: 'completed', progress: 100, message: 'Medical course content processed successfully!' });

    // Store mock data in sessionStorage for the next step
    sessionStorage.setItem('mockCourseData', JSON.stringify({
      ...courseData,
      fileName: selectedFile.name,
      pages: mockMedicalContent
    }));

    toast({
      title: "PDF uploaded successfully!",
      description: `5 pages of medical content detected and ready for AI summarization.`,
    });

    // Navigate to AI summary page after a short delay
    setTimeout(() => {
      navigate('/trainer/ai-summary');
    }, 2000);
  };

  const resetUpload = () => {
    setSelectedFile(null);
    setUploadState({ status: 'idle', progress: 0, message: '' });
  };

  return (
    <div className="max-w-4xl">
      <h2 className="text-2xl font-semibold text-gray-900 mb-2">Upload Course Content</h2>
      <p className="text-gray-600 mb-8">Upload your PDF course materials to begin the AI-enhanced content creation process</p>

      {/* Course Creation Form */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Course Information</CardTitle>
          <CardDescription>
            Provide basic information about your course before uploading content
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="title">Course Title</Label>
              <Input
                id="title"
                placeholder="e.g., Advanced Cardiovascular Medicine"
                value={courseData.title}
                onChange={(e) => setCourseData(prev => ({ ...prev, title: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="domain">Domain</Label>
              <Select value={courseData.domain} onValueChange={(value) => setCourseData(prev => ({ ...prev, domain: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select domain" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="medicine">Medicine & Healthcare</SelectItem>
                  <SelectItem value="programming">Programming & Development</SelectItem>
                  <SelectItem value="design">Design & Creativity</SelectItem>
                  <SelectItem value="business">Business & Management</SelectItem>
                  <SelectItem value="data-science">Data Science & Analytics</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Describe what students will learn in this course..."
              value={courseData.description}
              onChange={(e) => setCourseData(prev => ({ ...prev, description: e.target.value }))}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="level">Level</Label>
              <Select value={courseData.level} onValueChange={(value: any) => setCourseData(prev => ({ ...prev, level: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="beginner">Beginner</SelectItem>
                  <SelectItem value="intermediate">Intermediate</SelectItem>
                  <SelectItem value="advanced">Advanced</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="hours">Estimated Hours</Label>
              <Input
                id="hours"
                type="number"
                min="1"
                max="100"
                value={courseData.estimatedHours}
                onChange={(e) => setCourseData(prev => ({ ...prev, estimatedHours: parseInt(e.target.value) || 1 }))}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Upload Area */}
      <Card className="mb-6">
        <CardContent className="p-8">
          <div
            className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center hover:border-primary transition-colors cursor-pointer"
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onClick={() => document.getElementById('file-input')?.click()}
          >
            <input
              id="file-input"
              type="file"
              accept=".pdf"
              onChange={handleFileSelect}
              className="hidden"
            />
            
            {selectedFile ? (
              <div className="space-y-4">
                <FileText className="w-16 h-16 text-primary mx-auto" />
                <div>
                  <h3 className="text-lg font-medium text-gray-900">{selectedFile.name}</h3>
                  <p className="text-gray-600">{(selectedFile.size / (1024 * 1024)).toFixed(2)} MB</p>
                </div>
                <div className="flex justify-center space-x-4">
                  <Button onClick={handleUpload} disabled={!courseData.title}>
                    Process Medical Content
                  </Button>
                  <Button variant="outline" onClick={resetUpload}>
                    Choose Different File
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <CloudUpload className="w-16 h-16 text-gray-400 mx-auto" />
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Upload Medical Course PDF</h3>
                  <p className="text-gray-600 mb-4">Drag and drop your PDF file here, or click to browse</p>
                  <Button>
                    Select File
                  </Button>
                </div>
                <p className="text-sm text-gray-500">Supports PDF files up to 50MB - Will generate medical content for testing</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Upload Progress */}
      {uploadState.status !== 'idle' && (
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center mb-4">
              {uploadState.status === 'completed' ? (
                <CheckCircle className="text-secondary mr-3" size={24} />
              ) : uploadState.status === 'error' ? (
                <AlertCircle className="text-destructive mr-3" size={24} />
              ) : (
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mr-3"></div>
              )}
              <div className="flex-1">
                <p className="font-medium text-gray-900">{selectedFile?.name || 'Processing...'}</p>
                <p className="text-sm text-gray-600">{uploadState.message}</p>
              </div>
              <span className={`text-sm font-medium ${
                uploadState.status === 'completed' ? 'text-secondary' :
                uploadState.status === 'error' ? 'text-destructive' : 'text-primary'
              }`}>
                {uploadState.status === 'completed' ? 'Complete' :
                 uploadState.status === 'error' ? 'Error' : 
                 `${uploadState.progress}%`}
              </span>
            </div>
            
            {uploadState.status !== 'error' && (
              <Progress value={uploadState.progress} className="mb-4" />
            )}

            {uploadState.status === 'completed' && (
              <div className="text-sm text-gray-600 space-y-1">
                <div>✓ PDF uploaded successfully</div>
                <div>✓ Medical content extracted (5 pages)</div>
                <div>✓ Ready for AI summarization</div>
                <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                  <p className="text-blue-800 font-medium">Redirecting to AI Summary page...</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
