import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Users, BookOpen, TrendingUp, Award, Eye, PlayCircle, Clock, Star } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import type { Course } from "@shared/schema";
import { useState } from "react";

interface AnalyticsData {
  totalEnrollments: number;
  activeStudents: number;
  completionRate: number;
  averageRating: number;
  totalWatchTime: number;
  certificatesIssued: number;
}

interface StudentProgress {
  id: number;
  name: string;
  email: string;
  enrolledAt: string;
  progress: number;
  lastActive: string;
  status: "active" | "completed" | "inactive";
}

interface ModuleAnalytics {
  id: number;
  title: string;
  viewCount: number;
  avgWatchTime: number;
  completionRate: number;
  dropOffRate: number;
}

export default function Analytics() {
  const [selectedCourse, setSelectedCourse] = useState<string>("");
  const { user } = useAuth();

  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
    queryParams: { trainerId: user?.id },
    enabled: !!user,
  });

  // Mock analytics data
  const mockAnalytics: AnalyticsData = {
    totalEnrollments: 1247,
    activeStudents: 892,
    completionRate: 73,
    averageRating: 4.6,
    totalWatchTime: 15420, // minutes
    certificatesIssued: 456,
  };

  const mockStudents: StudentProgress[] = [
    {
      id: 1,
      name: "John Smith",
      email: "john@example.com",
      enrolledAt: "2024-01-15",
      progress: 85,
      lastActive: "2024-01-20",
      status: "active",
    },
    {
      id: 2,
      name: "Sarah Johnson",
      email: "sarah@example.com",
      enrolledAt: "2024-01-10",
      progress: 100,
      lastActive: "2024-01-18",
      status: "completed",
    },
    {
      id: 3,
      name: "Mike Chen",
      email: "mike@example.com",
      enrolledAt: "2024-01-12",
      progress: 45,
      lastActive: "2024-01-16",
      status: "active",
    },
    {
      id: 4,
      name: "Emily Davis",
      email: "emily@example.com",
      enrolledAt: "2024-01-08",
      progress: 30,
      lastActive: "2024-01-14",
      status: "inactive",
    },
    {
      id: 5,
      name: "Alex Wilson",
      email: "alex@example.com",
      enrolledAt: "2024-01-14",
      progress: 92,
      lastActive: "2024-01-19",
      status: "active",
    },
  ];

  const mockModuleAnalytics: ModuleAnalytics[] = [
    {
      id: 1,
      title: "Introduction to React",
      viewCount: 1180,
      avgWatchTime: 14.5,
      completionRate: 89,
      dropOffRate: 11,
    },
    {
      id: 2,
      title: "Components and JSX",
      viewCount: 1050,
      avgWatchTime: 16.2,
      completionRate: 82,
      dropOffRate: 18,
    },
    {
      id: 3,
      title: "State Management",
      viewCount: 890,
      avgWatchTime: 12.8,
      completionRate: 76,
      dropOffRate: 24,
    },
    {
      id: 4,
      title: "Event Handling",
      viewCount: 745,
      avgWatchTime: 13.1,
      completionRate: 71,
      dropOffRate: 29,
    },
  ];

  const selectedCourseData = courses.find(c => c.id.toString() === selectedCourse);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-secondary/10 text-secondary";
      case "active": return "bg-primary/10 text-primary";
      case "inactive": return "bg-gray-100 text-gray-600";
      default: return "bg-gray-100 text-gray-600";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed": return "Completed";
      case "active": return "Active";
      case "inactive": return "Inactive";
      default: return "Unknown";
    }
  };

  return (
    <div className="max-w-7xl">
      <h2 className="text-2xl font-semibold text-gray-900 mb-2">Course Analytics</h2>
      <p className="text-gray-600 mb-8">Track performance, engagement, and student progress across your courses</p>

      {/* Course Selection */}
      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="max-w-md">
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Course</label>
            <Select value={selectedCourse} onValueChange={setSelectedCourse}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a course to analyze" />
              </SelectTrigger>
              <SelectContent>
                {courses.map((course) => (
                  <SelectItem key={course.id} value={course.id.toString()}>
                    {course.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {selectedCourse && (
        <>
          {/* Overview Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="p-3 bg-primary/10 rounded-lg">
                    <Users className="text-primary" size={24} />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Enrollments</p>
                    <p className="text-2xl font-semibold text-gray-900">{mockAnalytics.totalEnrollments.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="p-3 bg-secondary/10 rounded-lg">
                    <TrendingUp className="text-secondary" size={24} />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Active Students</p>
                    <p className="text-2xl font-semibold text-gray-900">{mockAnalytics.activeStudents.toLocaleString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="p-3 bg-accent/10 rounded-lg">
                    <Award className="text-accent" size={24} />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Completion Rate</p>
                    <p className="text-2xl font-semibold text-gray-900">{mockAnalytics.completionRate}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="p-3 bg-yellow-100 rounded-lg">
                    <Star className="text-yellow-600" size={24} />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Average Rating</p>
                    <p className="text-2xl font-semibold text-gray-900">{mockAnalytics.averageRating}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {/* Student Progress */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Student Activity</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {mockStudents.map((student) => (
                    <div key={student.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <p className="font-medium text-gray-900">{student.name}</p>
                          <Badge className={`text-xs ${getStatusColor(student.status)}`}>
                            {getStatusText(student.status)}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{student.email}</p>
                        <div className="flex items-center space-x-2">
                          <Progress value={student.progress} className="flex-1 h-2" />
                          <span className="text-sm text-gray-600 min-w-[3rem]">{student.progress}%</span>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">
                          Last active: {new Date(student.lastActive).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Module Performance */}
            <Card>
              <CardHeader>
                <CardTitle>Module Performance</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {mockModuleAnalytics.map((module) => (
                    <div key={module.id} className="p-4 border border-gray-200 rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium text-gray-900">{module.title}</h4>
                        <div className="flex items-center space-x-4 text-sm text-gray-600">
                          <div className="flex items-center">
                            <Eye size={14} className="mr-1" />
                            <span>{module.viewCount}</span>
                          </div>
                          <div className="flex items-center">
                            <Clock size={14} className="mr-1" />
                            <span>{module.avgWatchTime}min</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm text-gray-600">Completion</span>
                            <span className="text-sm font-medium">{module.completionRate}%</span>
                          </div>
                          <Progress value={module.completionRate} className="h-2" />
                        </div>
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm text-gray-600">Drop-off</span>
                            <span className="text-sm font-medium text-destructive">{module.dropOffRate}%</span>
                          </div>
                          <Progress value={module.dropOffRate} className="h-2 bg-red-100" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Additional Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="mr-2" size={20} />
                  Watch Time
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="text-center">
                  <p className="text-3xl font-bold text-gray-900 mb-2">
                    {Math.floor(mockAnalytics.totalWatchTime / 60)}h {mockAnalytics.totalWatchTime % 60}m
                  </p>
                  <p className="text-sm text-gray-600">Total across all students</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Avg: {Math.floor(mockAnalytics.totalWatchTime / mockAnalytics.totalEnrollments)}min per student
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Award className="mr-2" size={20} />
                  Certificates
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="text-center">
                  <p className="text-3xl font-bold text-gray-900 mb-2">{mockAnalytics.certificatesIssued}</p>
                  <p className="text-sm text-gray-600">Issued this month</p>
                  <p className="text-xs text-gray-500 mt-1">
                    {Math.round((mockAnalytics.certificatesIssued / mockAnalytics.totalEnrollments) * 100)}% of enrollments
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BookOpen className="mr-2" size={20} />
                  Engagement
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Daily Active</span>
                    <span className="text-sm font-medium">78%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Weekly Active</span>
                    <span className="text-sm font-medium">65%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Monthly Active</span>
                    <span className="text-sm font-medium">89%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}

      {!selectedCourse && (
        <Card>
          <CardContent className="p-12 text-center">
            <TrendingUp size={64} className="mx-auto mb-4 text-gray-300" />
            <h3 className="text-xl font-medium text-gray-900 mb-2">Course Analytics Dashboard</h3>
            <p className="text-gray-600">Select a course to view detailed analytics and student progress</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
