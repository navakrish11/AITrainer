import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FileText, Bot, RefreshCw, Check, Edit, Wand2, Eye, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

interface PageContent {
  pageNumber: number;
  title: string;
  content: string;
  summary: string;
  status: 'pending' | 'approved' | 'editing';
}

export default function AISummary() {
  const [selectedPage, setSelectedPage] = useState<number>(1);
  const [customPrompt, setCustomPrompt] = useState("");
  const [isCustomPromptOpen, setIsCustomPromptOpen] = useState(false);
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [mockPages, setMockPages] = useState<PageContent[]>([]);
  const [editedSummary, setEditedSummary] = useState("");
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Load mock data from sessionStorage or use default
    const storedData = sessionStorage.getItem('mockCourseData');
    if (storedData) {
      const courseData = JSON.parse(storedData);
      setMockPages(courseData.pages.map((page: any) => ({
        ...page,
        status: 'pending' as const
      })));
    } else {
      // Default medical content if no uploaded data
      setMockPages([
        {
          pageNumber: 1,
          title: "Introduction to Cardiovascular Medicine",
          content: "Cardiovascular medicine focuses on the diagnosis and treatment of heart and blood vessel disorders...",
          summary: "Introduction to cardiovascular medicine covering heart and blood vessel disorders, including common conditions like coronary artery disease, heart failure, and hypertension.",
          status: 'pending' as const
        },
        {
          pageNumber: 2,
          title: "Diagnostic Procedures in Cardiology",
          content: "Modern cardiology employs various diagnostic techniques...",
          summary: "Overview of cardiac diagnostic procedures including ECG, echocardiography, cardiac catheterization, and stress testing for comprehensive heart evaluation.",
          status: 'pending' as const
        },
        {
          pageNumber: 3,
          title: "Pharmacological Interventions",
          content: "Cardiovascular pharmacology includes medications...",
          summary: "Key cardiovascular medications including ACE inhibitors, beta-blockers, diuretics, and anticoagulants, their mechanisms and therapeutic benefits.",
          status: 'pending' as const
        },
        {
          pageNumber: 4,
          title: "Surgical Interventions and Procedures",
          content: "Cardiac surgery encompasses procedures...",
          summary: "Major cardiac surgical procedures including CABG, valve replacement, and heart transplantation for treating severe cardiovascular conditions.",
          status: 'pending' as const
        },
        {
          pageNumber: 5,
          title: "Prevention and Lifestyle Management",
          content: "Cardiovascular disease prevention involves...",
          summary: "Cardiovascular disease prevention through lifestyle changes: regular exercise, healthy diet, smoking cessation, and stress management techniques.",
          status: 'pending' as const
        }
      ]);
    }
  }, []);

  useEffect(() => {
    const selectedPageData = mockPages.find(p => p.pageNumber === selectedPage);
    if (selectedPageData) {
      setEditedSummary(selectedPageData.summary);
    }
  }, [selectedPage, mockPages]);

  const selectedPageData = mockPages.find(p => p.pageNumber === selectedPage);

  const generateAlternativeSummaries = (originalSummary: string, prompt?: string) => {
    const alternatives = [
      "This comprehensive overview examines cardiovascular medicine with focus on evidence-based treatment approaches, covering pathophysiology, diagnostic methodologies, and therapeutic interventions for optimal patient outcomes.",
      "An in-depth analysis of cardiovascular disorders emphasizing clinical decision-making, patient assessment techniques, and multidisciplinary treatment strategies for improved cardiovascular health management.",
      "Detailed exploration of cardiac medicine principles including diagnostic protocols, pharmacological management, and procedural interventions designed to enhance understanding of cardiovascular disease treatment.",
      "Clinical perspective on cardiovascular medicine incorporating latest research findings, diagnostic innovations, and treatment modalities for comprehensive patient care in cardiac healthcare settings.",
      "Systematic approach to cardiovascular medicine covering fundamental concepts, diagnostic procedures, therapeutic options, and preventive strategies essential for modern cardiac care practice."
    ];

    if (prompt && prompt.toLowerCase().includes('simple')) {
      return "Simple explanation of heart medicine: doctors study heart problems, use tests to find issues, give medicines to help, and sometimes do surgery to fix heart problems.";
    }
    if (prompt && prompt.toLowerCase().includes('detailed')) {
      return alternatives[Math.floor(Math.random() * alternatives.length)] + " This expanded version includes comprehensive analysis of molecular mechanisms, advanced imaging techniques, and personalized medicine approaches.";
    }

    return alternatives[Math.floor(Math.random() * alternatives.length)];
  };

  const handleRegenerateSummary = async (customPrompt?: string) => {
    if (!selectedPageData) return;

    setIsRegenerating(true);

    // Simulate AI processing time
    await new Promise(resolve => setTimeout(resolve, 2000));

    const newSummary = generateAlternativeSummaries(selectedPageData.summary, customPrompt);

    setMockPages(prev => prev.map(page => 
      page.pageNumber === selectedPage 
        ? { ...page, summary: newSummary, status: 'pending' as const }
        : page
    ));

    setEditedSummary(newSummary);
    setIsRegenerating(false);
    setIsCustomPromptOpen(false);
    setCustomPrompt("");

    toast({
      title: "Summary regenerated!",
      description: customPrompt ? "Custom prompt applied successfully." : "New AI summary generated.",
    });
  };

  const handleSaveDraft = () => {
    if (!selectedPageData) return;

    setMockPages(prev => prev.map(page => 
      page.pageNumber === selectedPage 
        ? { ...page, summary: editedSummary, status: 'editing' as const }
        : page
    ));

    toast({
      title: "Draft saved",
      description: "Your changes have been saved as a draft.",
    });
  };

  const handleApprovePage = () => {
    if (!selectedPageData) return;

    setMockPages(prev => prev.map(page => 
      page.pageNumber === selectedPage 
        ? { ...page, summary: editedSummary, status: 'approved' as const }
        : page
    ));

    toast({
      title: "Page approved!",
      description: `Page ${selectedPage} summary has been approved.`,
    });
  };

  const handleApproveAll = () => {
    const unapprovedPages = mockPages.filter(page => page.status !== 'approved');

    if (unapprovedPages.length === 0) {
      // All already approved, proceed to avatar selection
      sessionStorage.setItem('approvedPages', JSON.stringify(mockPages));
      setLocation('/trainer/avatar-video');
      return;
    }

    setMockPages(prev => prev.map(page => ({ ...page, status: 'approved' as const })));

    toast({
      title: "All pages approved!",
      description: "All summaries have been approved. Proceeding to avatar selection...",
    });

    // Store approved pages and navigate after a short delay
    setTimeout(() => {
      sessionStorage.setItem('approvedPages', JSON.stringify(mockPages.map(page => ({ ...page, status: 'approved' }))));
      setLocation('/trainer/avatar-video');
    }, 2000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved": return "bg-secondary/10 text-secondary border-secondary";
      case "editing": return "bg-blue-100 text-blue-700 border-blue-200";
      case "pending": return "bg-orange-100 text-orange-700 border-orange-200";
      default: return "bg-gray-100 text-gray-600 border-gray-200";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "approved": return "Approved";
      case "editing": return "Draft Saved";
      case "pending": return "Pending Review";
      default: return "Draft";
    }
  };

  const approvedCount = mockPages.filter(page => page.status === 'approved').length;
  const totalPages = mockPages.length;

  return (
    <div className="max-w-6xl">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">AI-Powered Medical Summarization</h2>
          <p className="text-gray-600">Review and edit AI-generated summaries for each page of your medical course content</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-gray-600 mb-2">Progress: {approvedCount} of {totalPages} approved</p>
          <div className="w-32 bg-gray-200 rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300" 
              style={{ width: `${(approvedCount / totalPages) * 100}%` }}
            ></div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

        {/* Page Navigation */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Medical Course Pages ({totalPages} pages)</CardTitle>
          </CardHeader>
          <CardContent className="p-4 max-h-96 overflow-y-auto">
            <div className="space-y-2">
              {mockPages.map((page) => {
                const isSelected = selectedPage === page.pageNumber;

                return (
                  <div
                    key={page.pageNumber}
                    className={`flex items-center p-3 rounded-lg cursor-pointer transition-colors ${
                      isSelected ? 'border-l-4 border-primary bg-primary/5' : 'hover:bg-gray-50'
                    }`}
                    onClick={() => setSelectedPage(page.pageNumber)}
                  >
                    <div className="w-12 h-16 bg-gray-200 rounded border mr-3 flex-shrink-0 flex items-center justify-center">
                      {page.status === 'approved' ? (
                        <CheckCircle2 className="text-secondary" size={20} />
                      ) : (
                        <FileText className="text-gray-400" size={20} />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">Page {page.pageNumber}</p>
                      <p className="text-sm text-gray-600 line-clamp-2">{page.title}</p>
                      <div className="mt-1">
                        <Badge className={`text-xs border ${getStatusColor(page.status)}`}>
                          {getStatusText(page.status)}
                        </Badge>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Summary Editor */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Page {selectedPage}: {selectedPageData?.title}</CardTitle>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleRegenerateSummary()}
                  disabled={isRegenerating}
                >
                  <RefreshCw className={`mr-1 ${isRegenerating ? 'animate-spin' : ''}`} size={14} />
                  {isRegenerating ? 'Regenerating...' : 'Regenerate'}
                </Button>

                <Dialog open={isCustomPromptOpen} onOpenChange={setIsCustomPromptOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" disabled={isRegenerating}>
                      <Wand2 className="mr-1" size={14} />
                      Custom Prompt
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Custom AI Prompt</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="custom-prompt">Enter custom prompt for AI summarization</Label>
                        <Textarea
                          id="custom-prompt"
                          placeholder="e.g., 'Make this summary more simple and easy to understand' or 'Focus on practical clinical applications'"
                          value={customPrompt}
                          onChange={(e) => setCustomPrompt(e.target.value)}
                          rows={4}
                        />
                      </div>
                      <div className="bg-blue-50 p-3 rounded-lg">
                        <p className="text-sm text-blue-700">
                          Try prompts like: "simple explanation", "detailed analysis", "focus on treatment", "emphasize prevention"
                        </p>
                      </div>
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline" onClick={() => setIsCustomPromptOpen(false)}>
                          Cancel
                        </Button>
                        <Button
                          onClick={() => handleRegenerateSummary(customPrompt)}
                          disabled={!customPrompt.trim() || isRegenerating}
                        >
                          {isRegenerating ? "Generating..." : "Generate"}
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>

                <Button
                  variant="outline"
                  size="sm"
                  title="View Original Content"
                >
                  <Eye className="mr-1" size={14} />
                  View Original
                </Button>
              </div>
            </div>
          </CardHeader>

          <CardContent className="p-6">
            {selectedPageData ? (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="summary-text">AI-Generated Summary</Label>
                  <Textarea
                    id="summary-text"
                    className="min-h-32 mt-2"
                    value={editedSummary}
                    onChange={(e) => setEditedSummary(e.target.value)}
                    placeholder="AI summary will appear here..."
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Bot size={16} />
                    <span>Generated by Azure OpenAI GPT-4</span>
                    <Badge variant="outline" className="text-xs">Medical AI Model</Badge>
                  </div>

                  <div className="flex items-center space-x-3">
                    <Button
                      variant="outline"
                      onClick={handleSaveDraft}
                      disabled={editedSummary === selectedPageData.summary}
                    >
                      <Edit className="mr-1" size={14} />
                      Save Draft
                    </Button>
                    <Button
                      onClick={handleApprovePage}
                      disabled={selectedPageData.status === 'approved'}
                      className="bg-secondary hover:bg-secondary/90"
                    >
                      <Check className="mr-1" size={14} />
                      {selectedPageData.status === 'approved' ? 'Approved' : 'Approve'}
                    </Button>
                  </div>
                </div>

                {/* Original Content Preview */}
                <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                  <Label className="text-sm font-medium text-gray-700">Original Content Preview</Label>
                  <p className="text-sm text-gray-600 mt-1 line-clamp-3">
                    {selectedPageData.content}
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-gray-500">
                <Bot size={48} className="mx-auto mb-4 text-gray-300" />
                <p className="text-lg font-medium mb-2">No page selected</p>
                <p className="text-sm">Select a page to view and edit its summary</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Approve All Button */}
      <div className="mt-8 flex justify-center">
        <Button
          size="lg"
          onClick={handleApproveAll}
          className="bg-secondary hover:bg-secondary/90 px-8"
        >
          <CheckCircle2 className="mr-2" size={20} />
          {approvedCount === totalPages ? 'Proceed to Avatar Selection' : `Approve All (${totalPages - approvedCount} remaining)`}
        </Button>
      </div>

      {/* Progress Summary */}
      {approvedCount > 0 && (
        <Card className="mt-6">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <CheckCircle2 className="text-secondary" size={20} />
                <span className="font-medium text-gray-900">
                  {approvedCount} of {totalPages} pages approved
                </span>
              </div>
              {approvedCount === totalPages && (
                <Badge className="bg-secondary/10 text-secondary">
                  Ready for Avatar Selection
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}