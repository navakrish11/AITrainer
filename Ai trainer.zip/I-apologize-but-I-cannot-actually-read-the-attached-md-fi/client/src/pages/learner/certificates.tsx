import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Award, Download, Eye, Share2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import type { Certificate } from "@shared/schema";

interface CertificateWithCourse extends Certificate {
  course?: {
    title: string;
    trainer?: string;
  };
}

export default function Certificates() {
  const { user } = useAuth();

  const { data: certificates = [], isLoading } = useQuery<CertificateWithCourse[]>({
    queryKey: ["/api/certificates"],
    enabled: !!user,
  });

  // Mock certificates for demo
  const mockCertificates: CertificateWithCourse[] = [
    {
      id: 1,
      userId: user?.id || 1,
      courseId: 1,
      certificateId: "CERT-2024-001",
      issuedAt: new Date("2024-01-15"),
      pdfUrl: "/certificates/cert-001.pdf",
      course: {
        title: "React Fundamentals: Modern Web Development",
        trainer: "John Smith"
      }
    },
    {
      id: 2,
      userId: user?.id || 1,
      courseId: 2,
      certificateId: "CERT-2024-002",
      issuedAt: new Date("2024-02-20"),
      pdfUrl: "/certificates/cert-002.pdf",
      course: {
        title: "UI/UX Design Fundamentals",
        trainer: "Sarah Johnson"
      }
    },
    {
      id: 3,
      userId: user?.id || 1,
      courseId: 3,
      certificateId: "CERT-2024-003",
      issuedAt: new Date("2024-03-10"),
      pdfUrl: "/certificates/cert-003.pdf",
      course: {
        title: "Python Data Analysis Basics",
        trainer: "Mike Chen"
      }
    }
  ];

  if (isLoading) {
    return (
      <div className="space-y-6 animate-pulse">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-gray-200 rounded-lg"></div>
              <div className="flex-1 space-y-2">
                <div className="h-5 bg-gray-200 rounded w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/3"></div>
              </div>
              <div className="space-x-2">
                <div className="h-10 w-20 bg-gray-200 rounded inline-block"></div>
                <div className="h-10 w-20 bg-gray-200 rounded inline-block"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold text-gray-900 mb-2">My Certificates</h2>
        <p className="text-gray-600">Download and share your course completion certificates</p>
      </div>

      {mockCertificates.length > 0 ? (
        <div className="space-y-6">
          {mockCertificates.map((certificate) => (
            <Card key={certificate.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center space-x-6">
                  {/* Certificate Icon */}
                  <div className="w-16 h-16 bg-gradient-to-br from-accent to-accent/80 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Award className="text-white" size={32} />
                  </div>
                  
                  {/* Certificate Info */}
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="text-lg font-semibold text-gray-900">
                        {certificate.course?.title}
                      </h3>
                      <Badge variant="secondary" className="bg-accent/10 text-accent">
                        Verified
                      </Badge>
                    </div>
                    
                    <div className="space-y-1 text-sm text-gray-600">
                      <p>Instructor: {certificate.course?.trainer}</p>
                      <p>Certificate ID: {certificate.certificateId}</p>
                      <p>Issued: {certificate.issuedAt?.toLocaleDateString('en-US', { 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric' 
                      })}</p>
                    </div>
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="flex space-x-2 flex-shrink-0">
                    <Button variant="outline" size="sm">
                      <Eye size={16} className="mr-2" />
                      View
                    </Button>
                    <Button size="sm">
                      <Download size={16} className="mr-2" />
                      Download
                    </Button>
                    <Button variant="outline" size="sm">
                      <Share2 size={16} className="mr-2" />
                      Share
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <Award size={64} className="mx-auto mb-4 text-gray-300" />
          <h3 className="text-xl font-medium text-gray-900 mb-2">No certificates yet</h3>
          <p className="text-gray-600 mb-6">Complete courses to earn your first certificate!</p>
          <Button>
            Browse Courses
          </Button>
        </div>
      )}

      {/* Certificate Stats */}
      {mockCertificates.length > 0 && (
        <Card className="bg-gradient-to-r from-primary/5 to-accent/5 border-primary/20">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
              <div>
                <div className="text-2xl font-bold text-gray-900">{mockCertificates.length}</div>
                <div className="text-sm text-gray-600">Certificates Earned</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">
                  {new Set(mockCertificates.map(c => c.course?.trainer)).size}
                </div>
                <div className="text-sm text-gray-600">Different Instructors</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">
                  {mockCertificates.reduce((total, cert) => {
                    const monthsAgo = Math.floor((Date.now() - (cert.issuedAt?.getTime() || 0)) / (1000 * 60 * 60 * 24 * 30));
                    return total + Math.max(12 - monthsAgo, 0);
                  }, 0)}
                </div>
                <div className="text-sm text-gray-600">Learning Hours</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
