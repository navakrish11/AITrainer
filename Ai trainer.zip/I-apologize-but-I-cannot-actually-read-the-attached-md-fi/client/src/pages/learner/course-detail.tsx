import { useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Clock, Users, BarChart3, PlayCircle, CheckCircle, Star, Award, BookOpen } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import VideoPlayer from "@/components/video-player";
import Quiz from "@/components/quiz";
import { apiRequest } from "@/lib/queryClient";
import type { Course, Module, Enrollment, Progress as CourseProgress, Quiz as QuizType } from "@shared/schema";

interface CourseWithModules extends Course {
  modules?: Module[];
  isEnrolled?: boolean;
  userProgress?: CourseProgress[];
}

export default function CourseDetail() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentModuleId, setCurrentModuleId] = useState<number | null>(null);
  const [showQuiz, setShowQuiz] = useState(false);

  const { data: course, isLoading: courseLoading } = useQuery<CourseWithModules>({
    queryKey: ["/api/courses", id],
    enabled: !!id,
  });

  const { data: modules = [], isLoading: modulesLoading } = useQuery<Module[]>({
    queryKey: ["/api/courses", id, "modules"],
    enabled: !!id,
  });

  const { data: enrollment } = useQuery<Enrollment>({
    queryKey: ["/api/enrollments", id],
    enabled: !!user && !!id,
  });

  const { data: progress = [] } = useQuery<CourseProgress[]>({
    queryKey: ["/api/progress"],
    queryParams: { courseId: id },
    enabled: !!user && !!enrollment,
  });

  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments"],
    enabled: !!user,
  });

  const enrollMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/enrollments", {
        courseId: parseInt(id!),
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Enrolled successfully!",
        description: "You can now access the course content.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/enrollments"] });
    },
    onError: (error: any) => {
      toast({
        title: "Enrollment failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateProgressMutation = useMutation({
    mutationFn: async (data: { moduleId: number; videoProgress: number; completed: boolean }) => {
      const response = await apiRequest("POST", "/api/progress", {
        courseId: parseInt(id!),
        ...data,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/progress"] });
    },
  });

  if (courseLoading || modulesLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="bg-white rounded-xl p-6 mb-6">
              <div className="h-8 bg-gray-200 rounded w-3/4 mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2 mb-6"></div>
              <div className="grid grid-cols-4 gap-4">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="h-16 bg-gray-200 rounded"></div>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              <div className="lg:col-span-3">
                <div className="h-64 bg-gray-200 rounded-xl mb-6"></div>
                <div className="h-32 bg-gray-200 rounded-xl"></div>
              </div>
              <div className="h-96 bg-gray-200 rounded-xl"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">Course not found</h2>
          <p className="text-gray-600">The course you're looking for doesn't exist.</p>
        </div>
      </div>
    );
  }

  const isEnrolled = !!enrollment;
  const courseProgress = progress.reduce((acc, p) => acc + (p.completed ? 1 : 0), 0);
  const totalModules = modules.length;
  const progressPercentage = totalModules > 0 ? Math.round((courseProgress / totalModules) * 100) : 0;

  const currentModule = currentModuleId ? modules.find(m => m.id === currentModuleId) : modules[0];

  const handleEnroll = () => {
    enrollMutation.mutate();
  };

  const handleVideoProgress = (moduleId: number, progressPercent: number) => {
    updateProgressMutation.mutate({
      moduleId,
      videoProgress: progressPercent,
      completed: progressPercent >= 90,
    });
  };

  const handleVideoComplete = (moduleId: number) => {
    setShowQuiz(true);
    updateProgressMutation.mutate({
      moduleId,
      videoProgress: 100,
      completed: true,
    });
  };

  const handleQuizComplete = () => {
    setShowQuiz(false);
    toast({
      title: "Quiz completed!",
      description: "Great job! You can continue to the next module.",
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* Main Content */}
          <div className="lg:col-span-3">
            
            {/* Course Header */}
            <Card className="mb-6">
              <CardContent className="p-6">
                <div className="bg-gradient-to-r from-primary to-blue-600 text-white rounded-xl p-6 mb-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div>
                      <p className="text-blue-100 text-sm">Prerequisites</p>
                      <p className="font-medium">{course.prerequisites || "None"}</p>
                    </div>
                    <div>
                      <p className="text-blue-100 text-sm">Modules</p>
                      <p className="font-medium">{totalModules} modules</p>
                    </div>
                    <div>
                      <p className="text-blue-100 text-sm">Duration</p>
                      <p className="font-medium">{course.estimatedHours} hours</p>
                    </div>
                    <div>
                      <p className="text-blue-100 text-sm">Level</p>
                      <p className="font-medium">{course.level}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h1 className="text-2xl font-bold mb-2">{course.title}</h1>
                      <p className="text-blue-100 mb-4">{course.description}</p>
                    </div>
                    <div className="flex items-center">
                      <div className="flex text-yellow-300 mr-2">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} size={16} className={i < Math.floor(course.rating || 0) ? "fill-current" : ""} />
                        ))}
                      </div>
                      <span className="text-blue-100">{course.rating} ({course.reviewCount} reviews)</span>
                    </div>
                  </div>

                  {isEnrolled && (
                    <div className="mt-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-blue-100">Your Progress</span>
                        <span className="text-white font-medium">{progressPercentage}%</span>
                      </div>
                      <Progress value={progressPercentage} className="bg-blue-400" />
                    </div>
                  )}
                </div>

                {!isEnrolled && (
                  <div className="text-center">
                    <Button 
                      onClick={handleEnroll} 
                      size="lg" 
                      disabled={enrollMutation.isPending}
                      className="mb-4"
                    >
                      {enrollMutation.isPending ? "Enrolling..." : "Enroll in Course"}
                    </Button>
                    <p className="text-sm text-gray-600">Get access to all course materials and earn a certificate</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Course Content */}
            {isEnrolled && (
              <>
                {/* Video Player */}
                {currentModule && (
                  <Card className="mb-6">
                    <CardContent className="p-0">
                      <VideoPlayer
                        module={currentModule}
                        onProgress={(percent) => handleVideoProgress(currentModule.id, percent)}
                        onComplete={() => handleVideoComplete(currentModule.id)}
                      />
                    </CardContent>
                  </Card>
                )}

                {/* Quiz */}
                {showQuiz && currentModule && (
                  <Card className="mb-6">
                    <CardContent className="p-6">
                      <Quiz
                        moduleId={currentModule.id}
                        onComplete={handleQuizComplete}
                      />
                    </CardContent>
                  </Card>
                )}

                {/* Module List */}
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Course Modules</h3>
                    <Accordion type="single" collapsible className="w-full">
                      {modules.map((module, index) => {
                        const moduleProgress = progress.find(p => p.moduleId === module.id);
                        const isCompleted = moduleProgress?.completed || false;
                        const isActive = currentModuleId === module.id;
                        
                        return (
                          <AccordionItem key={module.id} value={`module-${module.id}`}>
                            <AccordionTrigger className="hover:no-underline">
                              <div className="flex items-center justify-between w-full mr-4">
                                <div className="flex items-center space-x-3">
                                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                                    isCompleted ? 'bg-secondary text-white' : 
                                    isActive ? 'bg-primary text-white' : 
                                    'bg-gray-200 text-gray-600'
                                  }`}>
                                    {isCompleted ? <CheckCircle size={16} /> : index + 1}
                                  </div>
                                  <div className="text-left">
                                    <p className="font-medium">{module.title}</p>
                                    <p className="text-sm text-gray-600">{module.description}</p>
                                  </div>
                                </div>
                                <div className="flex items-center space-x-2">
                                  {module.videoDuration && (
                                    <div className="flex items-center text-sm text-gray-500">
                                      <Clock size={14} className="mr-1" />
                                      <span>{Math.floor(module.videoDuration / 60)}:{(module.videoDuration % 60).toString().padStart(2, '0')}</span>
                                    </div>
                                  )}
                                  <Button
                                    size="sm"
                                    variant={isActive ? "default" : "outline"}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setCurrentModuleId(module.id);
                                      setShowQuiz(false);
                                    }}
                                  >
                                    <PlayCircle size={16} className="mr-1" />
                                    {isActive ? "Current" : "Play"}
                                  </Button>
                                </div>
                              </div>
                            </AccordionTrigger>
                            <AccordionContent>
                              <div className="pt-4 pl-11">
                                <p className="text-gray-600 mb-4">{module.description}</p>
                                {moduleProgress && (
                                  <div className="mb-2">
                                    <div className="flex items-center justify-between mb-1">
                                      <span className="text-sm text-gray-600">Progress</span>
                                      <span className="text-sm font-medium">{Math.round(moduleProgress.videoProgress || 0)}%</span>
                                    </div>
                                    <Progress value={moduleProgress.videoProgress || 0} className="h-2" />
                                  </div>
                                )}
                              </div>
                            </AccordionContent>
                          </AccordionItem>
                        );
                      })}
                    </Accordion>
                  </CardContent>
                </Card>
              </>
            )}

            {!isEnrolled && (
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Course Curriculum</h3>
                  <p className="text-gray-600 mb-4">Enroll to access {totalModules} modules with video content and interactive quizzes.</p>
                  <div className="space-y-3">
                    {modules.slice(0, 3).map((module, index) => (
                      <div key={module.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center text-sm font-medium text-gray-600">
                            {index + 1}
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{module.title}</p>
                            <p className="text-sm text-gray-600">{module.description}</p>
                          </div>
                        </div>
                        <div className="text-sm text-gray-500">
                          <Clock size={14} className="inline mr-1" />
                          {module.videoDuration ? `${Math.floor(module.videoDuration / 60)}:${(module.videoDuration % 60).toString().padStart(2, '0')}` : "5:30"}
                        </div>
                      </div>
                    ))}
                    {modules.length > 3 && (
                      <div className="text-center py-3 text-gray-500">
                        +{modules.length - 3} more modules
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="sticky top-8">
              <CardContent className="p-6">
                <h3 className="font-semibold text-gray-900 mb-4">My Enrolled Courses</h3>
                
                <div className="space-y-3">
                  {enrollments.slice(0, 5).map((enrollment) => (
                    <div key={enrollment.id} className={`p-3 rounded-lg border transition-colors cursor-pointer ${
                      enrollment.courseId === parseInt(id!) ? 'border-primary bg-primary/5' : 'border-gray-200 hover:bg-gray-50'
                    }`}>
                      <p className="font-medium text-gray-900 text-sm mb-1">
                        Course {enrollment.courseId}
                      </p>
                      <div className="flex items-center">
                        <Progress 
                          value={Math.floor(Math.random() * 100)} 
                          className="flex-1 mr-2 h-1.5" 
                        />
                        <span className="text-xs text-gray-600">{Math.floor(Math.random() * 100)}%</span>
                      </div>
                    </div>
                  ))}
                  
                  {enrollments.length === 0 && (
                    <div className="text-center py-4 text-gray-500">
                      <BookOpen size={32} className="mx-auto mb-2 text-gray-300" />
                      <p className="text-sm">No other courses yet</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
