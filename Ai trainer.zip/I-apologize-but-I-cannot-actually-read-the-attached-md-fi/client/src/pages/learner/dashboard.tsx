import { useQuery } from "@tanstack/react-query";
import { BookOpen, CheckCircle, Award } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import type { Enrollment, Course, Progress as CourseProgress } from "@shared/schema";

interface EnrollmentWithCourse extends Enrollment {
  course?: Course;
  progressPercentage?: number;
  currentModule?: string;
}

export default function Dashboard() {
  const { user } = useAuth();

  const { data: enrollments = [], isLoading: enrollmentsLoading } = useQuery<EnrollmentWithCourse[]>({
    queryKey: ["/api/enrollments"],
    enabled: !!user,
  });

  const { data: certificates = [], isLoading: certificatesLoading } = useQuery({
    queryKey: ["/api/certificates"],
    enabled: !!user,
  });

  const { data: progress = [], isLoading: progressLoading } = useQuery<CourseProgress[]>({
    queryKey: ["/api/progress"],
    enabled: !!user,
  });

  const isLoading = enrollmentsLoading || certificatesLoading || progressLoading;

  // Calculate stats
  const inProgressCourses = enrollments.filter(e => e.status === "active").length;
  const completedCourses = enrollments.filter(e => e.status === "completed").length;
  const certificateCount = certificates.length;

  // Mock current courses with progress for demo
  const currentCourses = enrollments.filter(e => e.status === "active").slice(0, 3).map(enrollment => ({
    ...enrollment,
    progressPercentage: Math.floor(Math.random() * 80) + 10, // Mock progress 10-90%
    currentModule: `Module ${Math.floor(Math.random() * 5) + 1}: ${["Introduction", "Getting Started", "Advanced Topics", "Best Practices", "Final Project"][Math.floor(Math.random() * 5)]}`,
    course: {
      id: enrollment.courseId,
      title: ["React Fundamentals", "Python for Data Science", "UI/UX Design Basics", "Node.js Backend"][Math.floor(Math.random() * 4)],
      thumbnailUrl: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=120"
    }
  }));

  if (isLoading) {
    return (
      <div className="space-y-8 animate-pulse">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="bg-white p-6 rounded-xl border border-gray-200">
              <div className="h-16 bg-gray-200 rounded"></div>
            </div>
          ))}
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold text-gray-900 mb-2">My Learning Dashboard</h2>
        <p className="text-gray-600">Track your progress and continue your learning journey</p>
      </div>

      {/* Progress Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 bg-primary/10 rounded-lg">
                <BookOpen className="text-primary" size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Courses in Progress</p>
                <p className="text-2xl font-semibold text-gray-900">{inProgressCourses}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 bg-secondary/10 rounded-lg">
                <CheckCircle className="text-secondary" size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Completed Courses</p>
                <p className="text-2xl font-semibold text-gray-900">{completedCourses}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 bg-accent/10 rounded-lg">
                <Award className="text-accent" size={24} />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Certificates Earned</p>
                <p className="text-2xl font-semibold text-gray-900">{certificateCount}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Current Courses with Progress */}
      <Card>
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Continue Learning</h3>
          
          {currentCourses.length > 0 ? (
            <div className="space-y-4">
              {currentCourses.map((enrollment) => (
                <div key={enrollment.id} className="flex items-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <img 
                    src={enrollment.course?.thumbnailUrl || "https://images.unsplash.com/photo-1633356122544-f134324a6cee?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=120"} 
                    alt="Course thumbnail" 
                    className="w-20 h-12 object-cover rounded-lg"
                  />
                  
                  <div className="ml-4 flex-1">
                    <h4 className="font-medium text-gray-900">{enrollment.course?.title}</h4>
                    <p className="text-sm text-gray-600">{enrollment.currentModule}</p>
                    
                    <div className="mt-2 flex items-center">
                      <Progress value={enrollment.progressPercentage} className="flex-1 mr-3" />
                      <span className="text-sm font-medium text-gray-600">{enrollment.progressPercentage}%</span>
                    </div>
                  </div>
                  
                  <Link href={`/course/${enrollment.courseId}`}>
                    <Button className="ml-4">
                      Continue
                    </Button>
                  </Link>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <BookOpen size={48} className="mx-auto mb-4 text-gray-300" />
              <p className="text-lg font-medium mb-2">No courses in progress</p>
              <p className="text-sm">Browse our course catalog to start learning!</p>
              <Link href="/">
                <Button className="mt-4">Browse Courses</Button>
              </Link>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
