import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Clock, PlayCircle } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import type { Enrollment } from "@shared/schema";

interface EnrollmentWithDetails extends Enrollment {
  course?: {
    id: number;
    title: string;
    thumbnailUrl?: string;
    estimatedHours?: number;
    level?: string;
  };
  progressPercentage?: number;
  modulesCompleted?: number;
  totalModules?: number;
}

export default function Learning() {
  const { user } = useAuth();

  const { data: enrollments = [], isLoading } = useQuery<EnrollmentWithDetails[]>({
    queryKey: ["/api/enrollments"],
    enabled: !!user,
  });

  // Mock enrollment data with course details for demo
  const mockEnrollments: EnrollmentWithDetails[] = [
    {
      id: 1,
      userId: user?.id || 1,
      courseId: 1,
      status: "active",
      enrolledAt: new Date(),
      course: {
        id: 1,
        title: "React Fundamentals: Modern Web Development",
        thumbnailUrl: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=240",
        estimatedHours: 12,
        level: "Beginner"
      },
      progressPercentage: 65,
      modulesCompleted: 5,
      totalModules: 8
    },
    {
      id: 2,
      userId: user?.id || 1,
      courseId: 2,
      status: "active",
      enrolledAt: new Date(),
      course: {
        id: 2,
        title: "Python for Data Science & AI",
        thumbnailUrl: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=240",
        estimatedHours: 16,
        level: "Intermediate"
      },
      progressPercentage: 35,
      modulesCompleted: 4,
      totalModules: 12
    },
    {
      id: 3,
      userId: user?.id || 1,
      courseId: 3,
      status: "completed",
      enrolledAt: new Date(),
      completedAt: new Date(),
      course: {
        id: 3,
        title: "UI/UX Design Fundamentals",
        thumbnailUrl: "https://images.unsplash.com/photo-1561070791-2526d30994b5?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=240",
        estimatedHours: 10,
        level: "Beginner"
      },
      progressPercentage: 100,
      modulesCompleted: 8,
      totalModules: 8
    }
  ];

  const activeCourses = mockEnrollments.filter(e => e.status === "active");
  const completedCourses = mockEnrollments.filter(e => e.status === "completed");

  if (isLoading) {
    return (
      <div className="space-y-6 animate-pulse">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center space-x-4">
              <div className="w-24 h-16 bg-gray-200 rounded"></div>
              <div className="flex-1 space-y-2">
                <div className="h-5 bg-gray-200 rounded w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                <div className="h-2 bg-gray-200 rounded w-full"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold text-gray-900 mb-2">My Learning</h2>
        <p className="text-gray-600">Continue where you left off and track your progress</p>
      </div>

      {/* Active Courses */}
      {activeCourses.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">In Progress ({activeCourses.length})</h3>
          <div className="space-y-4">
            {activeCourses.map((enrollment) => (
              <Card key={enrollment.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-6">
                    <img 
                      src={enrollment.course?.thumbnailUrl} 
                      alt={enrollment.course?.title}
                      className="w-24 h-16 object-cover rounded-lg"
                    />
                    
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-semibold text-gray-900 text-lg">{enrollment.course?.title}</h4>
                        <Badge variant={enrollment.course?.level === "Beginner" ? "secondary" : "outline"}>
                          {enrollment.course?.level}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center space-x-4 mb-3 text-sm text-gray-600">
                        <div className="flex items-center">
                          <Clock size={16} className="mr-1" />
                          <span>{enrollment.course?.estimatedHours} hours</span>
                        </div>
                        <div className="flex items-center">
                          <PlayCircle size={16} className="mr-1" />
                          <span>{enrollment.modulesCompleted}/{enrollment.totalModules} modules</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-4">
                        <Progress value={enrollment.progressPercentage} className="flex-1" />
                        <span className="text-sm font-medium text-gray-600 min-w-[3rem]">
                          {enrollment.progressPercentage}%
                        </span>
                      </div>
                    </div>
                    
                    <Link href={`/course/${enrollment.courseId}`}>
                      <Button>
                        Continue Learning
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Completed Courses */}
      {completedCourses.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Completed ({completedCourses.length})</h3>
          <div className="space-y-4">
            {completedCourses.map((enrollment) => (
              <Card key={enrollment.id} className="bg-green-50 border-green-200">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-6">
                    <img 
                      src={enrollment.course?.thumbnailUrl} 
                      alt={enrollment.course?.title}
                      className="w-24 h-16 object-cover rounded-lg"
                    />
                    
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-semibold text-gray-900 text-lg">{enrollment.course?.title}</h4>
                        <Badge className="bg-green-100 text-green-800">
                          Completed
                        </Badge>
                      </div>
                      
                      <div className="flex items-center space-x-4 mb-3 text-sm text-gray-600">
                        <div className="flex items-center">
                          <Clock size={16} className="mr-1" />
                          <span>{enrollment.course?.estimatedHours} hours</span>
                        </div>
                        <div className="flex items-center">
                          <PlayCircle size={16} className="mr-1" />
                          <span>{enrollment.totalModules} modules</span>
                        </div>
                      </div>
                      
                      <div className="text-sm text-green-700">
                        Completed on {enrollment.completedAt?.toLocaleDateString()}
                      </div>
                    </div>
                    
                    <div className="flex space-x-2">
                      <Link href={`/course/${enrollment.courseId}`}>
                        <Button variant="outline">
                          Review
                        </Button>
                      </Link>
                      <Link href="/certificates">
                        <Button>
                          View Certificate
                        </Button>
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Empty State */}
      {activeCourses.length === 0 && completedCourses.length === 0 && (
        <div className="text-center py-12">
          <BookOpen size={64} className="mx-auto mb-4 text-gray-300" />
          <h3 className="text-xl font-medium text-gray-900 mb-2">No courses yet</h3>
          <p className="text-gray-600 mb-6">Start learning by enrolling in your first course!</p>
          <Link href="/">
            <Button>Browse Courses</Button>
          </Link>
        </div>
      )}
    </div>
  );
}
