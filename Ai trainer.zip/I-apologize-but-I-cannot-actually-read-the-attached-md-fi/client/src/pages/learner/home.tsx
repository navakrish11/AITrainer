import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import CourseCard from "@/components/course-card";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Play, Clock, Users, Star, User } from "lucide-react";
import type { Course } from "@shared/schema";

const domains = [
  {
    id: "medical",
    title: "Medical & Healthcare",
    description: "Medical education, healthcare training, and clinical skills"
  },
  {
    id: "programming",
    title: "Programming & Development",
    description: "Learn coding, web development, and software engineering"
  },
  {
    id: "design",
    title: "Design & Creativity", 
    description: "UI/UX design, graphic design, and creative skills"
  },
  {
    id: "business",
    title: "Business & Management",
    description: "Leadership, project management, and entrepreneurship"
  },
  {
    id: "data-science",
    title: "Data Science & Analytics",
    description: "Data analysis, machine learning, and AI"
  }
];

export default function HomePage() {
  const { data: apiCourses = [], isLoading } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });
  
  const [publishedCourses, setPublishedCourses] = useState<any[]>([]);
  
  useEffect(() => {
    // Load published courses from localStorage
    const courses = JSON.parse(localStorage.getItem('publishedCourses') || '[]');
    setPublishedCourses(courses);
  }, []);
  
  // Combine API courses and published courses
  const allCourses = [...apiCourses, ...publishedCourses];

  if (isLoading) {
    return (
      <div className="space-y-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <div className="h-48 bg-gray-200"></div>
                <div className="p-5 space-y-3">
                  <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                  <div className="h-5 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-full"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">Explore by Domain</h2>

        {domains.map((domain) => {
          const domainCourses = allCourses.filter(course => course.domain === domain.id);

          if (domainCourses.length === 0) return null;

          return (
            <div key={domain.id} className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">{domain.title}</h3>
                  <p className="text-sm text-gray-600">{domain.description}</p>
                </div>
                <Button variant="outline" size="sm">
                  View All
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {domainCourses.slice(0, 4).map((course) => (
                  course.videos ? (
                    // Custom card for published courses
                    <Card key={course.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                      <div className="aspect-video bg-gradient-to-br from-blue-500 to-purple-600 relative">
                        <img 
                          src={course.thumbnail} 
                          alt={course.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                          <Play className="text-white" size={24} />
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <Badge variant="secondary" className="mb-2 text-xs">
                          {course.domain === 'medical' ? 'Medical' : course.domain}
                        </Badge>
                        <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
                          {course.title}
                        </h3>
                        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                          {course.description}
                        </p>
                        
                        <div className="flex items-center space-x-2 mb-3">
                          <Avatar className="w-6 h-6">
                            <AvatarImage src={course.avatar?.image} alt={course.avatar?.name} />
                            <AvatarFallback className="text-xs">
                              <User size={12} />
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-xs text-gray-600">{course.avatar?.name}</span>
                        </div>

                        <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                          <div className="flex items-center space-x-1">
                            <Clock size={12} />
                            <span>{course.duration}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Users size={12} />
                            <span>{course.studentsCount} students</span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-1">
                            <Star className="text-yellow-400 fill-current" size={12} />
                            <span className="text-xs font-medium">{course.rating}</span>
                          </div>
                          <Badge className="bg-green-100 text-green-700 text-xs">
                            {course.videos.length} videos
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ) : (
                    <CourseCard key={course.id} course={course} />
                  )
                ))}
              </div>
            </div>
          );
        })}

        {allCourses.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-400 text-lg mb-4">No courses available yet</div>
            <p className="text-gray-600">Check back soon for new courses!</p>
          </div>
        )}
      </div>
    </div>
  );
}