import { pgTable, text, serial, integer, boolean, timestamp, jsonb, real } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("learner"), // "learner" or "trainer"
  firstName: text("first_name"),
  lastName: text("last_name"),
  profileImage: text("profile_image"),
  timezone: text("timezone").default("UTC"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  shortDescription: text("short_description"),
  domain: text("domain").notNull(), // "programming", "design", etc.
  level: text("level").notNull(), // "beginner", "intermediate", "advanced"
  prerequisites: text("prerequisites"),
  estimatedHours: integer("estimated_hours"),
  thumbnailUrl: text("thumbnail_url"),
  rating: real("rating").default(0),
  reviewCount: integer("review_count").default(0),
  status: text("status").default("draft"), // "draft", "published", "unpublished"
  trainerId: integer("trainer_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const modules = pgTable("modules", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id").references(() => courses.id),
  title: text("title").notNull(),
  description: text("description"),
  videoUrl: text("video_url"),
  videoDuration: integer("video_duration"), // in seconds
  orderIndex: integer("order_index").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const quizzes = pgTable("quizzes", {
  id: serial("id").primaryKey(),
  moduleId: integer("module_id").references(() => modules.id),
  courseId: integer("course_id").references(() => courses.id),
  title: text("title").notNull(),
  questions: jsonb("questions").notNull(), // Array of question objects
  passingScore: integer("passing_score").default(70), // percentage
  type: text("type").default("module"), // "module" or "final"
  createdAt: timestamp("created_at").defaultNow(),
});

export const enrollments = pgTable("enrollments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  courseId: integer("course_id").references(() => courses.id),
  enrolledAt: timestamp("enrolled_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  status: text("status").default("active"), // "active", "completed", "paused"
});

export const progress = pgTable("progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  courseId: integer("course_id").references(() => courses.id),
  moduleId: integer("module_id").references(() => modules.id),
  videoProgress: real("video_progress").default(0), // percentage watched
  completed: boolean("completed").default(false),
  lastWatchedAt: timestamp("last_watched_at").defaultNow(),
});

export const quizAttempts = pgTable("quiz_attempts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  quizId: integer("quiz_id").references(() => quizzes.id),
  answers: jsonb("answers").notNull(), // User's answers
  score: integer("score").notNull(), // percentage score
  passed: boolean("passed").notNull(),
  attemptedAt: timestamp("attempted_at").defaultNow(),
});

export const certificates = pgTable("certificates", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  courseId: integer("course_id").references(() => courses.id),
  certificateId: text("certificate_id").notNull().unique(), // unique certificate identifier
  issuedAt: timestamp("issued_at").defaultNow(),
  pdfUrl: text("pdf_url"),
});

export const courseMaterials = pgTable("course_materials", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id").references(() => courses.id),
  pdfUrl: text("pdf_url"),
  pageCount: integer("page_count"),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
});

export const pageSummaries = pgTable("page_summaries", {
  id: serial("id").primaryKey(),
  materialId: integer("material_id").references(() => courseMaterials.id),
  pageNumber: integer("page_number").notNull(),
  originalText: text("original_text"),
  summary: text("summary"),
  status: text("status").default("pending"), // "pending", "approved", "needs_review"
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const avatarVideos = pgTable("avatar_videos", {
  id: serial("id").primaryKey(),
  summaryId: integer("summary_id").references(() => pageSummaries.id),
  avatarId: text("avatar_id").notNull(), // HeyGen avatar ID
  voiceId: text("voice_id").notNull(), // HeyGen voice ID
  videoUrl: text("video_url"),
  status: text("status").default("pending"), // "pending", "generating", "completed", "failed"
  heygenJobId: text("heygen_job_id"), // HeyGen generation job ID
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  courses: many(courses),
  enrollments: many(enrollments),
  progress: many(progress),
  quizAttempts: many(quizAttempts),
  certificates: many(certificates),
}));

export const coursesRelations = relations(courses, ({ one, many }) => ({
  trainer: one(users, { fields: [courses.trainerId], references: [users.id] }),
  modules: many(modules),
  quizzes: many(quizzes),
  enrollments: many(enrollments),
  progress: many(progress),
  certificates: many(certificates),
  materials: many(courseMaterials),
}));

export const modulesRelations = relations(modules, ({ one, many }) => ({
  course: one(courses, { fields: [modules.courseId], references: [courses.id] }),
  quizzes: many(quizzes),
  progress: many(progress),
}));

export const quizzesRelations = relations(quizzes, ({ one, many }) => ({
  module: one(modules, { fields: [quizzes.moduleId], references: [modules.id] }),
  course: one(courses, { fields: [quizzes.courseId], references: [courses.id] }),
  attempts: many(quizAttempts),
}));

export const enrollmentsRelations = relations(enrollments, ({ one }) => ({
  user: one(users, { fields: [enrollments.userId], references: [users.id] }),
  course: one(courses, { fields: [enrollments.courseId], references: [courses.id] }),
}));

export const progressRelations = relations(progress, ({ one }) => ({
  user: one(users, { fields: [progress.userId], references: [users.id] }),
  course: one(courses, { fields: [progress.courseId], references: [courses.id] }),
  module: one(modules, { fields: [progress.moduleId], references: [modules.id] }),
}));

export const quizAttemptsRelations = relations(quizAttempts, ({ one }) => ({
  user: one(users, { fields: [quizAttempts.userId], references: [users.id] }),
  quiz: one(quizzes, { fields: [quizAttempts.quizId], references: [quizzes.id] }),
}));

export const certificatesRelations = relations(certificates, ({ one }) => ({
  user: one(users, { fields: [certificates.userId], references: [users.id] }),
  course: one(courses, { fields: [certificates.courseId], references: [courses.id] }),
}));

export const courseMaterialsRelations = relations(courseMaterials, ({ one, many }) => ({
  course: one(courses, { fields: [courseMaterials.courseId], references: [courses.id] }),
  summaries: many(pageSummaries),
}));

export const pageSummariesRelations = relations(pageSummaries, ({ one, many }) => ({
  material: one(courseMaterials, { fields: [pageSummaries.materialId], references: [courseMaterials.id] }),
  videos: many(avatarVideos),
}));

export const avatarVideosRelations = relations(avatarVideos, ({ one }) => ({
  summary: one(pageSummaries, { fields: [avatarVideos.summaryId], references: [pageSummaries.id] }),
}));

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true, updatedAt: true });
export const insertCourseSchema = createInsertSchema(courses).omit({ id: true, createdAt: true, updatedAt: true });
export const insertModuleSchema = createInsertSchema(modules).omit({ id: true, createdAt: true });
export const insertQuizSchema = createInsertSchema(quizzes).omit({ id: true, createdAt: true });
export const insertEnrollmentSchema = createInsertSchema(enrollments).omit({ id: true, enrolledAt: true });
export const insertProgressSchema = createInsertSchema(progress).omit({ id: true, lastWatchedAt: true });
export const insertQuizAttemptSchema = createInsertSchema(quizAttempts).omit({ id: true, attemptedAt: true });
export const insertCertificateSchema = createInsertSchema(certificates).omit({ id: true, issuedAt: true });
export const insertCourseMaterialSchema = createInsertSchema(courseMaterials).omit({ id: true, uploadedAt: true });
export const insertPageSummarySchema = createInsertSchema(pageSummaries).omit({ id: true, createdAt: true, updatedAt: true });
export const insertAvatarVideoSchema = createInsertSchema(avatarVideos).omit({ id: true, createdAt: true });

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = typeof courses.$inferSelect;
export type InsertModule = z.infer<typeof insertModuleSchema>;
export type Module = typeof modules.$inferSelect;
export type InsertQuiz = z.infer<typeof insertQuizSchema>;
export type Quiz = typeof quizzes.$inferSelect;
export type InsertEnrollment = z.infer<typeof insertEnrollmentSchema>;
export type Enrollment = typeof enrollments.$inferSelect;
export type InsertProgress = z.infer<typeof insertProgressSchema>;
export type Progress = typeof progress.$inferSelect;
export type InsertQuizAttempt = z.infer<typeof insertQuizAttemptSchema>;
export type QuizAttempt = typeof quizAttempts.$inferSelect;
export type InsertCertificate = z.infer<typeof insertCertificateSchema>;
export type Certificate = typeof certificates.$inferSelect;
export type InsertCourseMaterial = z.infer<typeof insertCourseMaterialSchema>;
export type CourseMaterial = typeof courseMaterials.$inferSelect;
export type InsertPageSummary = z.infer<typeof insertPageSummarySchema>;
export type PageSummary = typeof pageSummaries.$inferSelect;
export type InsertAvatarVideo = z.infer<typeof insertAvatarVideoSchema>;
export type AvatarVideo = typeof avatarVideos.$inferSelect;
